const fs = require('fs')
const chalk = require('chalk')
const moment = require("moment-timezone");
const { pickRandom } = require('./lib/myfunc')
moment.tz.setDefault('Asia/Jakarta');
let d = new Date
let locale = 'id'
let gmt = new Date(0).getTime() - new Date('1 Januari 2021').getTime()




global.weton = ['Pahing', 'Pon','Wage','Kliwon','Legi'][Math.floor(((d * 1) + gmt) / 84600000) % 5]
global.week = d.toLocaleDateString(locale, { weekday: 'long' })
global.calender = d.toLocaleDateString("id", {day: 'numeric', month: 'long', year: 'numeric'})
global.owner = ['6281316701742'] 
global.botname = 'sɪᴇsᴛᴀ ɴᴀᴛsᴜɢᴀɴɪ'
global.packname = '' 
global.author = "—Satzz Takeshi."
global.prefa = ['','!','.',',','🐤','🗿']
global.wm = 'sɪᴇsᴛᴀ ɴᴀᴛsᴜɢᴀɴɪ'
global.botName = 'sɪᴇsᴛᴀ ɴᴀᴛsᴜɢᴀɴɪ'
global.img = [
'https://i.pinimg.com/originals/2a/22/36/2a2236dfc851b031ffba6d38da820199.jpg',
'https://i.pinimg.com/originals/b2/b0/55/b2b05536877d959188fefdfc8859ca48.jpg',
'https://i.pinimg.com/originals/a3/e3/80/a3e380001bf41eae0c94e3a8a77448e7.jpg',
'https://i.pinimg.com/originals/58/fa/92/58fa92ec9b7f7dfbd7a4c0e85fff9b63.jpg',
'https://i.pinimg.com/originals/80/a8/49/80a849ebe4faf4898043b8e2f7511fa4.jpg',
'https://i.pinimg.com/originals/32/af/52/32af52b47fa09035254ec1b5699c3b77.jpg',
'https://i.pinimg.com/originals/44/39/25/443925a23c98edcac3137033bcfcc381.jpg',
'https://i.pinimg.com/originals/d9/7a/ea/d97aea69e721a63e488e7cdf9ef7a60a.jpg',
'https://i.pinimg.com/originals/91/fc/ef/91fcef2247b15c59393a57818bdcf1d3.jpg',
'https://i.pinimg.com/originals/71/88/80/718880cfcb8b9b68355f496d5d57d865.jpg',
'https://i.pinimg.com/originals/d3/f1/ee/d3f1eeac92259bcd65c4b7e3c6440a44.jpg',
'https://i.pinimg.com/originals/3a/d4/b7/3ad4b75e3c2f0c6568868e2cef3e5f18.jpg',
'https://i.pinimg.com/originals/96/3a/ab/963aab1f8a06f722f7d421132307ab59.jpg',
'https://i.pinimg.com/originals/59/ee/6f/59ee6f0ef66a167eeb7c3f9f5630350e.jpg',
'https://i.pinimg.com/originals/34/84/75/34847524a7fc23e998c5866cfa313107.jpg',
'https://i.pinimg.com/originals/f4/aa/2d/f4aa2d6b5a02ae5dc92fb62c3c99b06e.jpg',
'https://i.pinimg.com/originals/2e/2c/ed/2e2ced5fc6fa5161d7c000596ad53299.jpg',
'https://i.pinimg.com/originals/9f/ec/9c/9fec9c406d39023c8f24b293379ed09c.jpg',
'https://i.pinimg.com/originals/13/ab/30/13ab30a71be3cf1264a91fd95ba070da.jpg',
'https://i.pinimg.com/originals/46/bc/50/46bc50da99a99a2891a5b011fec9a617.jpg',
'https://i.pinimg.com/originals/78/59/9f/78599fb0f47f76462f33e2eb65c2a5cc.jpg',
'https://i.pinimg.com/originals/75/2b/b9/752bb9cc261768d0ab08d94f4cf31044.jpg'
]
global.sessionName = 'session' 
global.sp = '⭔' 
global.sgc = "https://chat.whatsapp.com/G6W25LQb4Ce2i8r4Z0du1q"
global.link = "https://instagram.com/kurniawan_satria__"
global.githubcode = "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"
global.limitawal = {
premium: "Infinity",
free: 10
}


global.mess = {
success: "Dekita!", 
wait: "Chotto Matte Kudasai!", 
premium: "[❗] Khusus Pengguna Premium!",
owner: "[❗] Khusus Pemilik!",
admin: "[❗] Khusus Admin!",
grup: "[❗] Khusus Grup!",
group: "[❗] Khusus Grup!",
bodmin: "[❗] Bot Harus Menjadi Admin Terlebih Dahulu!",
limit: "[❗] Batas Anda habis, silakan mainkan permainan untuk mendapatkannya!",
}

global.annotations = 
[{"polygonVertices": [{"x": 0.13409259915351868,"y": 0.6821129322052002},{"x": 0.8658981323242188,"y": 0.6821129322052002},{"x": 0.8658981323242188,"y": 0.7446132898330688},{"x": 0.13409259915351868,"y": 0.7446132898330688}],
"newsletter": {
"newsletterJid": "120363229748458166@newsletter",
"newsletterName": "WhatsApp Status ✅",
"contentType": 1,
"accessibilityText": "WhatsApp Status ✅"
},
"shouldSkipConfirmation": true
},{"polygonVertices": [{"x": 0.06704629957675934,"y": 0.2165948748588562},{"x": 0.9329444766044617,"y": 0.2165948748588562},{"x": 0.9329444766044617,"y": 0.7823269963264465},{"x": 0.06704629957675934,"y": 0.7823269963264465}],
"bussiness": {
"newsletterJid": "120363229748458166@newsletter",
"newsletterName": "WhatsApp Status ✅",
"contentType": 1,
"accessibilityText": "WhatsApp Status ✅"
}, 
"shouldSkipConfirmation": true
}
]








let file = require.resolve(__filename);
fs.watchFile(file, () => {
fs.unwatchFile(file);
console.log(chalk.blueBright(`「 Updated 」 ${__filename}`));
delete require.cache[file];
require(file);
});