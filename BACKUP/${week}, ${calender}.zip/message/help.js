/* SC SIESTA - MD V5
BASE : HISOKA OLD
CREATOR : SATZZ
*/
const fs = require('fs')
const chalk = require('chalk')
const moment = require("moment-timezone")
const timeWib = moment().tz('Asia/Jakarta').format('HH:mm:ss')
const timeWit= moment().tz('Asia/Makassar').format('HH:mm:ss')
const timeWita = moment().tz('Asia/Jayapura').format('HH:mm:ss')
moment.tz.setDefault("Asia/Jakarta").locale("id");
const { getAllCmd, runtime } = require("../lib/myfunc")



const more = String.fromCharCode(8206)
const readmore = more.repeat(4001) 
let dt = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('a')
const timem = moment().tz('Asia/Jakarta');

let ucapanWaktu = '';

if (timem.isBetween(moment('00:00:00', 'HH:mm:ss'), moment('11:00:00', 'HH:mm:ss'))) {
    ucapanWaktu = 'Ohayōgozaimasu!';
} else if (timem.isBetween(moment('11:00:00', 'HH:mm:ss'), moment('15:00:00', 'HH:mm:ss'))) {
    ucapanWaktu = 'Konnichiwa!';
} else if (timem.isBetween(moment('15:00:00', 'HH:mm:ss'), moment('18:00:00', 'HH:mm:ss'))) {
    ucapanWaktu = 'Konbanwa!';
} else {
    ucapanWaktu = 'Oyasuminasai!';
}

let dot = new Date(new Date + 3600000)
const dateIslamic = Intl.DateTimeFormat("id" + '-TN-u-ca-islamic', {day: 'numeric',month: 'long',year: 'numeric'}).format(dot)
const totalF = getAllCmd().length
const menuList = (sender, jumlah_user) => `
${ucapanWaktu} *@${sender.split('@')[0]}* ୧⍤⃝💐

╭─▸ ⭓ _~ＵＳＥＲ - ＩＮＦＯ~_
│ ⎚ ɴᴜᴍʙᴇʀ : _${sender.split('@')[0]}_
│ ⎚ ʀᴇɢɪꜱᴛᴇʀᴇᴅ ᴀᴛ : ${db.data.users[sender].date}
│ ⎚ ʟɪᴍɪᴛ : ${db.data.users[sender].premium ? '♾️ Unlimited.' : db.data.users[sender].limit}
│ ⎚ ꜱᴛᴀᴛᴜꜱ : ${db.data.users[sender].premium ? '👑 Premium User.' : '👎 Free user.'}
└───────୧⍤⃝💐


╭─▸ ⭓ _~ＩＮＦＯ - ＢＯＴ~_
│ ⎚ ʟɪʙʀᴀʀʏ : @whiskeysockets/baileys
│ ⎚ ғᴇᴀᴛᴜʀᴇ : ${totalF} Feature Total.
│ ⎚ ᴘᴏᴡᴇʀᴇᴅ ʙʏ : 🐦 Ptrodactyl Panel
│ ⎚ ʀᴜɴᴛɪᴍᴇ : ⏳ ${runtime(process.uptime())}
└───────୧⍤⃝💐


╭─▸ ⭓ _~ＴＩＭＥ - ＳＥＲＶＥＲ~_
│ ⎚ ${week}, ${calender} 
│ ⎚ ${timeWib} WIB 
│ ⎚ ${dateIslamic} 
└───────୧⍤⃝💐


.allmenu (untuk menampilkan semua menu)
`
const allMenu = () => `
╭─▸ 〔 _~ＡＩ~_ 〕
│ _*~=>~*_ .ai
│ _*~=>~*_ .img
╰────────────୧⍤⃝💐


╭─▸ 〔 _~ＣＯＮＶＥＲＴＥＲ~_ 〕
│ _*~=>~*_ .qc
│ _*~=>~*_ .emojimix
│ _*~=>~*_ .emojimix2
│ _*~=>~*_ .sticker
│ _*~=>~*_ .smeme
│ _*~=>~*_ .bass
│ _*~=>~*_ .blown
│ _*~=>~*_ .deep
│ _*~=>~*_ .earrape
│ _*~=>~*_ .fast
│ _*~=>~*_ .fat
│ _*~=>~*_ .nightcore
│ _*~=>~*_ .reverse
│ _*~=>~*_ .robot
│ _*~=>~*_ .slow
│ _*~=>~*_ .toaudio
│ _*~=>~*_ .toimg
│ _*~=>~*_ .tomp3
│ _*~=>~*_ .tovideo
│ _*~=>~*_ .tovn
│ _*~=>~*_ .tupai
╰────────────୧⍤⃝💐


╭─▸ 〔 _~ＤＯＷＮＬＯＡＤＥＲ~_ 〕
│ _*~=>~*_ (kirim link saja untuk instagram/tiktok)
│ _*~=>~*_ .spotifydl
│ _*~=>~*_ .ttaudio
│ _*~=>~*_ .ytmp3
│ _*~=>~*_ .ytmp4
│ _*~=>~*_ .gdrive
│ _*~=>~*_ .mediafire
│ _*~=>~*_ .pinterestdl
╰────────────୧⍤⃝💐


╭─▸ 〔 _~ＴＯＯＬＳ & ＳＥＡＲＣＨ~_ 〕
│ _*~=>~*_ .couple
│ _*~=>~*_ .remini
│ _*~=>~*_ .stickersearch
│ _*~=>~*_ .ocr
│ _*~=>~*_ .removebg
│ _*~=>~*_ .couple
│ _*~=>~*_ .lirik
│ _*~=>~*_ .menfess
│ _*~=>~*_ .pinterest
│ _*~=>~*_ .play
│ _*~=>~*_ .translate
│ _*~=>~*_ .ytsearch
╰────────────୧⍤⃝💐


╭─▸ 〔 _~ＦＵＮ~_ 〕
│ _*~=>~*_ .bisakah
│ _*~=>~*_ .bagaimanakah
│ _*~=>~*_ .apakah
│ _*~=>~*_ .kapankah
│ _*~=>~*_ .cekwatak
│ _*~=>~*_ .cekhobby
│ _*~=>~*_ .cekmemek
│ _*~=>~*_ .cekkontol
│ _*~=>~*_ .genjot
│ _*~=>~*_ .nenen
│ _*~=>~*_ .perkosa
│ _*~=>~*_ .curhat
│ _*~=>~*_ .jodohku
╰────────────୧⍤⃝💐


╭─▸ 〔 _~ＲＡＮＤＯＭ~_ 〕
│ _*~=>~*_ .asupan
│ _*~=>~*_ .quotessad
│ _*~=>~*_ .senja
│ _*~=>~*_ .akira 
│ _*~=>~*_ .akiyama 
│ _*~=>~*_ .anna 
│ _*~=>~*_ .asuna 
│ _*~=>~*_ .ayuzawa 
│ _*~=>~*_ .boruto 
│ _*~=>~*_ .chitanda 
│ _*~=>~*_ .chitoge 
│ _*~=>~*_ .deidara 
│ _*~=>~*_ .doraemon 
│ _*~=>~*_ .elaina 
│ _*~=>~*_ .emilia 
│ _*~=>~*_ .asuna 
│ _*~=>~*_ .erza 
│ _*~=>~*_ .gremory 
│ _*~=>~*_ .hestia 
│ _*~=>~*_ .hinata 
│ _*~=>~*_ .inori 
│ _*~=>~*_ .isuzu 
│ _*~=>~*_ .itachi 
│ _*~=>~*_ .itori 
│ _*~=>~*_ .kaga 
│ _*~=>~*_ .kagura 
│ _*~=>~*_ .kakasih 
│ _*~=>~*_ .kaori 
│ _*~=>~*_ .kosaki 
│ _*~=>~*_ .kotori 
│ _*~=>~*_ .kuriyama 
│ _*~=>~*_ .kuroha 
│ _*~=>~*_ .kurumi 
│ _*~=>~*_ .loli 
│ _*~=>~*_ .madara 
│ _*~=>~*_ .mikasa 
│ _*~=>~*_ .miku 
│ _*~=>~*_ .minato 
│ _*~=>~*_ .naruto 
│ _*~=>~*_ .natsukawa 
│ _*~=>~*_ .neko2 
│ _*~=>~*_ .nekohime 
│ _*~=>~*_ .nezuko 
│ _*~=>~*_ .nishimiya 
│ _*~=>~*_ .onepiece 
│ _*~=>~*_ .pokemon 
│ _*~=>~*_ .rem 
│ _*~=>~*_ .rize 
│ _*~=>~*_ .sagiri 
│ _*~=>~*_ .sakura 
│ _*~=>~*_ .sasuke 
│ _*~=>~*_ .shina 
│ _*~=>~*_ .shinka 
│ _*~=>~*_ .shizuka 
│ _*~=>~*_ .shota 
│ _*~=>~*_ .tomori 
│ _*~=>~*_ .toukachan 
│ _*~=>~*_ .tsunade 
│ _*~=>~*_ .yatogami 
│ _*~=>~*_ .yuki 
╰────────────୧⍤⃝💐


╭─▸ㅤ〔 _~ＧＲＯＵＰ~_ 〕
│ _*~=>~*_ .banned
│ _*~=>~*_ .unbanned
│ _*~=>~*_ .listbanned
│ _*~=>~*_ .linkgc
│ _*~=>~*_ .nsfw
│ _*~=>~*_ .kick
│ _*~=>~*_ .add
│ _*~=>~*_ .close
│ _*~=>~*_ .open
│ _*~=>~*_ .promote
│ _*~=>~*_ .demote
│ _*~=>~*_ .setdesc
│ _*~=>~*_ .setnamegc
│ _*~=>~*_ .setppgc
│ _*~=>~*_ .closetime
│ _*~=>~*_ .opentime
│ _*~=>~*_ .hidetag
│ _*~=>~*_ .tagall
╰────────────୧⍤⃝💐


╭─▸ 〔 _~ＭＡＩＮ~_ 〕
│ _*~=>~*_ .owner
│ _*~=>~*_ .runtime
│ _*~=>~*_ .speed
│ _*~=>~*_ .gcbot
╰────────────୧⍤⃝💐


╭─▸ 〔 _~ＯＷＮＥＲ~_ 〕
│ _*~=>~*_ .banned
│ _*~=>~*_ .unbanned
│ _*~=>~*_ .listbanned
│ _*~=>~*_ .public
│ _*~=>~*_ .self
│ _*~=>~*_ .backup
│ _*~=>~*_ .getcase
│ _*~=>~*_ .addfile
│ _*~=>~*_ .addprem
│ _*~=>~*_ .delprem
│ _*~=>~*_ .restart
│ _*~=>~*_ .$
│ _*~=>~*_ .>
╰────────────୧⍤⃝💐


_© 2024 || SatganzDevs Alright Reserved._`;
module.exports = { menuList, allMenu }


//━━━━━━━━━━━━━━━[ DETECT FILE UPDATE ]━━━━━━━━━━━━━━━━━\\
let file = require.resolve(__filename);
fs.watchFile(file, () => {
fs.unwatchFile(file);
console.log(chalk.bgCyanBright(chalk.black("[ UPDATE ]")),chalk.red(`${__filename}`))
delete require.cache[file];
require(file);
});