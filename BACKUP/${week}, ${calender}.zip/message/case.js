/* 
• RECODE: SATZZ
• GITHUB: https://github.com/SatganzDevs
• INSTAGRAM: https://instagram.com/kurniawan_satria__
*/




require("../config");
const { proto, getContentType, generateWAMessageFromContent, downloadContentFromMessage } = require("@whiskeysockets/baileys");
const fs = require("fs")
const moment = require("moment-timezone");
const ytdl = require("ytdl-core");
const util = require("util");
const chalk = require("chalk");
const fetch = require("node-fetch");
const speed = require("performance-now");
const axios = require("axios");
const { uptotelegra } = require("../lib/uploader");
const { exec } = require("child_process");
const cron = require("node-cron");
const Scraper = require("@bochilteam/scraper")
moment.tz.setDefault('Asia/Jakarta');



//━━━━━━━━━━━━━━━[ LIBRARY ]━━━━━━━━━━━━━━━━━//
const { reSize, ucapanWaktu, formatp, getBuffer, getCases, generateProfilePicture, sleep, fetchJson, runtime, pickRandom, getGroupAdmins, getRandom } = require("../lib/myfunc")
const { uploadToGH } = require('../lib/github')
const _prem = require("../lib/premium.js")
const _ban = require("../lib/banned.js")



//━━━━━━━━━━━━━━━[ DATABASE ]━━━━━━━━━━━━━━━━━//
const ban = db.data.banned
const premium = db.data.premium



//━━━━━━━━━━━━━━━[ START OF EXPORT ]━━━━━━━━━━━━━━━━━//
module.exports = Satzz = async (Satzz, m, chatUpdate, store) => {
try {
const body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const prefix = '.'
const isCmd = body.startsWith(prefix);
const command = body.replace(prefix, "").trim().split(/ +/).shift().toLowerCase();
var args = body.trim().split(/ +/).slice(1);
args = args.concat(["", "", "", "", "", ""]);
const pushname = m.pushName || "No Name";
const botNumber = await Satzz.decodeJid(Satzz.user.id);
const isCreator = global.owner + "@s.whatsapp.net" === m.sender ? true :  false
const isOwner = isCreator
const itsMe = m.sender == botNumber ? true : false;
const from = m.chat;
const q = args.join(" ").trim();
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const senderNumber = m.sender.split("@")[0];




//━━━━━━━━━━━━━━━[ CHECKER ]━━━━━━━━━━━━━━━━━//
const isPremium = isOwner ? true : _prem.checkPremiumUser(m.sender, premium)
const isBanned = m.sender? _ban.check(senderNumber, ban) : false



//━━━━━━━━━━━━━━━[ GROUP-FUNC ]━━━━━━━━━━━━━━━━━//
const groupMetadata = m.isGroup ? await Satzz.groupMetadata(m.chat).catch((e) => { }) : ""; 
const groupName = groupMetadata.subject
const participants = m.isGroup ? await groupMetadata.participants : "";
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : "";
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false;
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false;



//━━━━━━━━━━━━━━━[ USERS PFP ]━━━━━━━━━━━━━━━━━//
let ppuser = await Satzz.profilePictureUrl(m.sender, "image").catch(_ => "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60");



//━━━━━━━━━━━━━━━[ FAKE QUOTED ]━━━━━━━━━━━━━━━━━//
const thumb = await getBuffer(await pickRandom(global.img))
const tt = await reSize(ppuser, 200, 200)
const ftroli ={key: {fromMe: false,"participant":"0@s.whatsapp.net", "remoteJid": "status@broadcast"}, "message": {orderMessage: {itemCount: 2022,status: 200, thumbnail: tt, surface: 200, message: botname, orderTitle: wm, sellerJid: '0@s.whatsapp.net'}}, contextInfo: {"forwardingScore":999,"isForwarded":true},sendEphemeral: true}
const fdoc ={key : {participant : '0@s.whatsapp.net', ...(m.chat ? { remoteJid: `status@broadcast` } : {}) },message: {documentMessage: {title: botname,jpegThumbnail: tt}}}
const fvn ={key: {participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {})},message: { "audioMessage": {"mimetype":"audio/ogg; codecs=opus","seconds":359996400,"ptt": "true"}} } 
const fgif ={key: {participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {})},message: {"videoMessage": { "title":botname, "h": wm,"seconds": '359996400', "gifPlayback": 'true', "caption": wm, "jpegThumbnail": tt}}}
const fgclink ={key: {participant: "0@s.whatsapp.net","remoteJid": "0@s.whatsapp.net"},"message": {"groupInviteMessage": {"groupJid": "6283137499954-1616169743@g.us","inviteCode": "m","groupName": wm, "caption": `${pushname}`, "jpegThumbnail": tt}}}
const fvideo ={key: { fromMe: false,participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {}) },message: { "videoMessage": { "title":botname, "h": wm,"seconds": '359996400', "caption": `${pushname}`, "jpegThumbnail": tt}}}
const floc ={key : {participant : '0@s.whatsapp.net', ...(m.chat ? { remoteJid: `status@broadcast` } : {}) },message: {locationMessage: {name: wm,jpegThumbnail: tt}}}
const repPy ={key: {fromMe: false,"participant":"0@s.whatsapp.net", "remoteJid": "status@broadcast"}, message: { requestPaymentMessage: { currencyCodeIso4217: "USD",amount1000: 999999999,requestFrom: '0@s.whatsapp.net',noteMessage: {extendedTextMessage: { text: wm}},expiryTimestamp: 999999999,amount: { value: 91929291929, offset: 1000, currencyCode: "USD"}}}}
const setQuoted = await pickRandom([ftroli,fdoc,fvn,fgif,fgclink,fvideo,floc,repPy])



//━━━━━━━━━━━━━━━[ FAKE CONTEXTINFO ]━━━━━━━━━━━━━━━━━//
const contextInfo = { isForwarded: true, forwardingScore: 1000, forwardedNewsletterMessageInfo: { newsletterJid: "120363229748458166@newsletter", serverMessageId: 100, newsletterName: "WhatsApp Status ✅"}, businessMessageForwardInfo: {businessOwnerJid: botNumber},
}



//━━━━━━━━━━━━━━━[ FAKE REPLY ]━━━━━━━━━━━━━━━━━//
const reply = async(teks) => { return Satzz.sendMessage(m.chat, {text: teks, contextInfo:{ mentionedJid: [...teks.matchAll(/@([0-9]{5,16}|0)/g)].map((v) => v[1] + "@s.whatsapp.net") || [m.sender], isForwarded: true, forwardingScore: 1000, forwardedNewsletterMessageInfo: {newsletterJid: "120363229748458166@newsletter", serverMessageId: 100, newsletterName: "WhatsApp Status ✅"}, externalAdReply: {showAdAttribution: true, renderLargerThumbnail: false, containsAutoReply: true, previewType: "PHOTO", title: `⌜ ${wm} ⌟`, body: ucapanWaktu, mediaType: "IMAGE", sourceUrl: link, thumbnail: thumb}}},{ quoted: m })}



//━━━━━━━━━━━━━━━[ REACTION ]━━━━━━━━━━━━━━━━━//
const react = async (emoti) => { return Satzz.sendMessage(from, {react: {text: emoti,key: {remoteJid: m.chat,fromMe: false,key: m.key,id: m.key.id,participant: m.sender}}})}



//━━━━━━━━━━━━━━━[ DB USER ]━━━━━━━━━━━━━━━━━//
const isNumber = (x) => typeof x === "number" && !isNaN(x);
let user = db.data.users[m.sender];
let limitUser = 10;
if (typeof user !== "object") db.data.users[m.sender] = {};
if (user) {
if (!('name' in user)) user.name = pushname;
if (!('id' in user)) user.id = senderNumber;
if (!isNumber(user.limit)) user.limit = limitUser;
if (!("premium" in user)) user.premium = false;
if (!isNumber(user.afkTime)) user.afkTime = -1;
if (!("afkReason" in user)) user.afkReason = "";
} else {
global.db.data.users[m.sender] = {
name: pushname,
id: senderNumber,
date: global.calender,
limit: limitUser,
premium: false,
afkTime: -1,
afkReason: ""
}
}



//━━━━━━━━━━━━━━━[ DB GROUP CHAT ]━━━━━━━━━━━━━━━━━//
let chats = db.data.chats[m.chat];
if (typeof chats !== "object") db.data.chats[m.chat] = {};
if (chats) {
if (!("antibadword" in chats)) chats.antibadword = false;
if (!("antidelete" in chats)) chats.antidelete = false;
if (!("antilink" in chats)) chats.antilink = false;
if (!("antiviewonce" in chats)) chats.antiviewonce = false;
if (!("mute" in chats)) chats.mute = false;
if (!("nsfw" in chats)) chats.nfsw = false;
} else
global.db.data.chats[m.chat] = {
antibadword: false,
antidelete: false,
antilink: false,
antiviewonce: false,
mute: false,
nsfw: false
};

    


//━━━━━━━━━━━━━━━[ LOGGING MESSAGE ]━━━━━━━━━━━━━━━━━//
if (isCmd) {
console.log(chalk.bgYellowBright(chalk.black("[ COMMAND ]")),
chalk.green(moment.tz('Asia/Jakarta').format('HH:mm')),
chalk.blue(`${command} [${args.length}]`), 
chalk.cyan('from'),
chalk.red(`${pushname}`), m.isGroup? `${chalk.red('in group')} ${chalk.red(groupName)}` : "")
}



//━━━━━━━━━━━━━━━[ PUBLIC & SELF ]━━━━━━━━━━━━━━━━━//
if (!Satzz.public) {
if (!m.key.fromMe && !isCreator) return;
}



//━━━━━━━━━━━━━━━[ GROUP MEMBER ONLY ]━━━━━━━━━━━━━━━━━//
if (!m.isGroup && isCmd) {
let gc = await Satzz.groupMetadata("120363140569875100@g.us")
let gcm = await gc.participants
let all_member = gcm.map((a) => a.id)
if (!all_member.includes(m.sender)) return Satzz.sendMessage(m.chat, {text:`kamu belum masuk grup offical, masuk terlebih dahulu untuk menggunakan bot.\n\n`,contextInfo:{ isForwarded: true, forwardingScore: 1000,forwardedNewsletterMessageInfo: {newsletterJid: "120363229748458166@newsletter",serverMessageId: 100,newsletterName: "WhatsApp Status ✅"},externalAdReply: {renderLargerThumbnail: true,containsAutoReply: true,title: `⌜ ${wm} ⌟`, body: ucapanWaktu, mediaType: 1, sourceUrl: sgc,thumbnail: thumb}}},{ quoted: m });
}



//━━━━━━━━━━━━━━━[ ANTI DELETE ]━━━━━━━━━━━━━━━━━//
if (m.mtype == 'protocolMessage' && !itsMe && !m.key.remoteJid.includes('status@broadcast')) {
let mess = chatUpdate.messages[0].message.protocolMessage
let chats = Object.entries(await Satzz.chats).find(([user, data]) => data.messages && data.messages[mess.key.id])
if (chats[1] !== undefined) {
let msg = JSON.parse(JSON.stringify(chats[1].messages[mess.key.id]))
let mmk = await Satzz.copyNForward(mess.key.remoteJid, msg).catch(e => console.log(e, msg))
Satzz.sendMessage(mess.key.remoteJid, {text:`⟮ *_~ANTI DELETE~_* ⟯\n\n◩ _~TYPE:~_ ${Object.keys(msg.message)[0]}\n◩ _~SENDER:~_ ${mess.sender}\n`, contextInfo },{quoted:msg})
}
}



//━━━━━━━━━━━━━━━[ MENFESS RESPONSE ]━━━━━━━━━━━━━━━━━//
if (m.chat.endsWith("@s.whatsapp.net") && m.message) {
this.menfess = this.menfess ? this.menfess : {};
let room = Object.values(this.menfess).find((room) => [room.a, room.b].includes(m.sender) && room.state === "ACTIVE");
if (room) {
if (/^.*(keluar|deletemenfess|hapusmenfess|batal)/.test(m.text)) {
reply(`\`\`\`Kamu Telah Meninggalkan Sesi Menfess\`\`\``);
let other = room.other(m.sender);
if (other) await Satzz.sendText(other, `\`\`\`Partner Telah Meninggalkan Sesi Menfess\`\`\``);
delete this.menfess[room.id];
}
let other = [room.a, room.b].find((user) => user !== m.sender);
m.copyNForward(other, true, m.quoted && m.quoted.fromMe ? {contextInfo: {...m.msg.contextInfo, forwardingScore: 0, isForwarded: true, participant: other }} : {});
}
}



//━━━━━━━━━━━━━━━[ MENFESS WAITING ]━━━━━━━━━━━━━━━━━//
if (m.chat.endsWith("@s.whatsapp.net") && m.message) {
this.menfess = this.menfess ? this.menfess : {};
let room = Object.values(this.menfess).find((room) => [room.a, room.b].includes(m.sender) && room.state === "WAITING");
if (room) {
if (m.sender == room.b) {
if (m.text == "Y") {
reply("Anonymous Chat Telah Tersambung\nKetik .hapusmenfess untuk berhenti");
room.state = "ACTIVE";
let other = [room.a, room.b].find((user) => user !== m.sender);
Satzz.sendMessage(other, {text: "Penerima Telah Menkonfirmasi, sekarang Anonymous Chat Telah Tersambung"},{quoted: setQuoted});
}
if (m.text == "N") {
m.reply("oke.");
let other = [room.a, room.b].find((user) => user !== m.sender);
Satzz.sendMessage(other, {text: "Penerima Menolak Anonymous, NiceTry Ya wkwk 😁👍"},{ quoted: setQuoted });
delete this.menfess[room.id];
}
}
}
}



//━━━━━━━━━━━━━━━[ RESET LIMIT ]━━━━━━━━━━━━━━━━━//
let isTaskRunning = false;
const finishTask = () => {
isTaskRunning = false;
};
const reset_limit = cron.schedule("0 0 * * *", () => {
if (isTaskRunning) return;
isTaskRunning = true;
let user = Object.keys(global.db.data.users);
let limitUser = isOwner ? 'unlimited' : 20;
for (let jid of user) { 
global.db.data.users[jid].limit = limitUser 
}
Satzz.sendMessage("120363140569875100@g.us", {text: "limit user telah di reset."});
finishTask();
}, { scheduled: true, timezone: "Asia/Jakarta" });

    
        
//━━━━━━━━━━━━━━━[ ANTI TOXIC ]━━━━━━━━━━━━━━━━━//
let badwordRegex = /anj(k|g)|ajn?(g|k)|a?njin(g|k)|bajingan|b(a?n)?gsa?t|ko?nto?l|me?me?(k|q)|pe?pe?(k|q)|meki|pe?ler|tetek|toket|ngewe|go?blo?k|to?lo?l|idiot|(k|ng)e?nto?(t|d)|jembut|bego|dajj?al|janc(u|o)k|pantek|puki ?(mak)?|kimak|kampang|lonte|col(i|mek?)|pelacur|henceu?t|nigga|fuck|dick|bitch|tits|bastard|asshole|pntk|shit|dick/i 
let isBadword = badwordRegex.test(budy.toLowerCase())
if (isBadword) {
Satzz.sendMessage(from, {audio: await getBuffer('https://github.com/SatganzDevs/DATABASES/raw/main/VN/jan%20toksis.opus'), ptt: true, wavefrom: new Uint8Array(64), mimetype: 'audio/ogg; codecs=opus'},{quoted:m})
}
 


//━━━━━━━━━━━━━━━[ ANTI LINK ]━━━━━━━━━━━━━━━━━//
if (budy.match(`chat.whatsapp.com`) && isBotAdmins) {
Satzz.sendMessage(m.chat, { delete: { remoteJid: m.chat, id: m.key.id, participant: m.sender }});
//Satzz.groupParticipantsUpdate(m.chat, [m.sender], "remove");
}  



//━━━━━━━━━━━━━━━[ ANTI VIEWONCE ]━━━━━━━━━━━━━━━━━//
if (m.mtype === "viewOnceMessageV2" && !itsMe)  {
await Satzz.sendMessage(m.chat, {react: {text: "🤨", key: {remoteJid: m.chat, fromMe: false, key: m.key, id: m.key.id, participant: m.sender}}})
var view = m.message.viewOnceMessageV2.message
let Type = Object.keys(view)[0]
let media = await downloadContentFromMessage(view[Type], Type == "imageMessage" ? "image" : "video")
let buffer = Buffer.from([])
for await (const chunk of media) {
buffer = Buffer.concat([buffer, chunk])
}
if (/video/.test(Type)) {
Satzz.sendMessage(m.chat, {video: buffer, caption:view[Type].caption || '', contextInfo},{quoted: m})
} else if (/image/.test(Type)) {
Satzz.sendMessage(m.chat, {image: buffer, caption:view[Type].caption || '', contextInfo},{quoted: m})
}
}



//━━━━━━━━━━━━━━━[ AUTO DL INSTAGRAM ]━━━━━━━━━━━━━━━━━//
if (budy.startsWith("https://") && budy.includes("instagram.com")) {
if (!isPremium && db.data.users[m.sender].limit < 1) return reply(mess.limit);
react('⏳')
try {
let res = await Scraper.snapsave(budy)
for (let i of res) { Satzz.sendFileUrl(from, i.url, '', m, {contextInfo}) }
} catch (e) {
console.log(e) 
reply("error :(") 
}



//━━━━━━━━━━━━━━━[ AUTO DL TIKTOK ]━━━━━━━━━━━━━━━━━//
} else if (budy.startsWith("https://") && budy.includes("tiktok")) {
if (!isPremium && db.data.users[m.sender].limit < 1) return reply(mess.limit);
react('⏳')
const { TiktokDownloader } = require("@tobyg74/tiktok-api-dl")
let result = await TiktokDownloader(budy, {version: "v2"})
await reply(`⟮ _~TIKTOK DOWNLOADER~_ ⟯\n\n⭔ *Desc* : ${result.result.desc}`)
if (result.result.type == 'image') { 
for (let i of result.result.images) { 
await Satzz.sendFileUrl(m.chat, i, "", m, {contextInfo})
}
} else if (result.result.type == 'video') { 
await Satzz.sendFileUrl(m.chat, result.result.video, "", m, {contextInfo}) 
}
 


//━━━━━━━━━━━━━━━[ EVAL ]━━━━━━━━━━━━━━━━━//
} else if (budy.startsWith(">")) {
if (!isCreator && !itsMe) return reply(global.mess.owner);
const evalAsync = () => { return new Promise(async (resolve, reject) => {
try {
let evaled = await eval(budy.slice(2));
if (typeof evaled !== "string")
evaled = require("util").inspect(evaled);
resolve(evaled) } catch (err) { reject(err) }})};
evalAsync().then((result) => reply(result)).catch((err) => reply(String(err)));    



//━━━━━━━━━━━━━━━[ EXEC ]━━━━━━━━━━━━━━━━━//
} else if (budy.startsWith("$")){
if (!isCreator && !itsMe) return reply(global.mess.owner);
reply("Executing...");
exec(budy.slice(2), async (err, stdout) => {
if (err) return m.reply(`${err}`);
if (stdout) return m.reply(stdout);
});     



//━━━━━━━━━━━━━━━[ SIMI ]━━━━━━━━━━━━━━━━━//
} else if ( !itsMe && !m.isGroup && !isCmd && m.mtype == "extendedTextMessage" || !m.isGroup && !isCmd && m.mtype == "conversation" && !budy.startsWith('https://')) {
try {
const options = new URLSearchParams();
options.append('text', budy);
options.append('lc', 'id');
const response = await axios.post('https://api.simsimi.vn/v2/simtalk', options);
let res = await response.data;
reply(res.message);
} catch (error) {reply(pickRandom(["apalah","ga tw","ak ga phm, ak ms kcil","mksdnya?"]))}};



const blockcmd = JSON.parse(fs.readFileSync("./src/blockcmd.json"));
// blockcmd
if (isCmd && blockcmd.includes(command)) return reply("*⌜ blocked ⌟*\n\nThis command has been blocked");



_prem.expiredCheck(Satzz, premium)



if (isCmd) {
switch (command) {
//━━━━━━━━━━━━━━━[ RANDOM ]━━━━━━━━━━━━━━━━━//
case "quotessad":{
let satzz_lagi_galau = [
'kita diberi kebebasan untuk mencintai, tapi tidak diberi kewajiban untuk memiliki.',
'bahkan disaat rasamu telah mati, aku masih disini menunggu rasamu kembali.',
'Aku tidak berhenti menyayangimu, aku hanya menguranginya agar tidak terlalu sakit kedepannya.',
'Dia tidak menyukaimu, Dia hanya menghargai Usahamu.',
'Datang Karena Penasaran, Pergi Karena Sudah Tau Kekuranga.n',
'Semesta memintaku melepaskan mu, padahal menggenggam mu saja belum.',
'Kita di pertemukan oleh waktu karena ketidaksengajaan lalu bersama dan setelah itu akhirnya kita berpisah karena berakhir tak bahagia bila bersamamu.',
'Semua orang memaksaku melupakanmu, tapi tak satupun dari mereka memberi tauku bagaimana caranya.',
'siapa sangka, wajah semanis senja, memberi luka sedalam samudra.',
'serasi tapi tak serasa, kita memang dua tokoh utama namun ternyata di cerita yang berbeda, kita memiliki banyak persamaan tetapi tidak untuk perasaan.',
'saya tidak menyangka hubungan antara dua insan manusia akan sedemikian indah tapi perih. - BJ Habibie',
'Bukan dia yang menghilang, kau saja yang mengira dia akan menetap padahal baginya dirimu hanya untuk dikenal kemudian kembali melanjutkan hidupnya yang tidak mengerti arti kata tinggal.',
'Sewajarnya saja ya, karna semua bisa mengecewakan pada waktunya.',
'bahkan sekarang pun aku hanya bisa mengagumimu,sebagai bentuk rasaku.',
'Dia tidak menyakitimu,tpi harapamu yang menyakiti dirimu.',
'Walau akhirnya tak jadi satu, Setidaknya semesta pernah menjadi saksi bahwa aku pernah begitu mengharapkanmu.',
'kita hanya sepatas pernah, bukan punah, bukan menyerah, hanya sudah.',
'Walau berakhir tak bahagia, tapi setidaknya pernah bahagia bersama.',
'Kamu ibaratkan bulan indah dan bersinar tapi sayang kau hanya hadir untuk sementara bukan selamanya',
'Mencintaimu seperti air laut, pasang surut akan selalu ada. Tapi kau tau, air laut tak pernah berubah rasa.',
'Kebahagiaan sebenarnya adalah ketika bisa melihat dia baik baik saja walau tidak bisa bersama.',
'Aku tidak berhenti mencintaimu, aku hanya melepasmu, agar kamu bahagia walau bahagiamu bukan aku.',
'aku bersyukur atas kehadiranmu , meskipun kamu hanya hadir bukan takdir.',
'Aku terlalu larut dalam bait bait indah puisimu hingga lupa di setiap aksaramu, tokoh utamanya bukan aku. -Satzz',
'Berawal dari "Isi Hati" yang tak bisa di ucapkan, semua kisah bersamanya pun menjadi "Akhir tak bahagia".',
'Aku mencoba mencari pengganti mu, tapi nyatanya aku mencari dirimu di diri orang lain.',
'Laku mu penuh tentang indah hari esok, Namun ujarmu penuh dengan luka.',
'Mengharapkan Cinta yang  berlebihan dari seseorang yang kita tak bisa di gapai hanya akan membuat dirimu tertampar dengan kenyataan',
'Aku tahu bahwa semesta mempertemukan mu hanya sebagai kisah bukan kasih. -Satzz',
'Mencintaimu adalah suatu keinginan, Memilikimu adalah suatu kemustahilan',
'Mungkin pertemuan kita hanyalah sebuah kilasan waktu yang terus berjalan, semoga kita menemukan yang memang terbaik untuk kita.',
'cerita singkat namun melekat, sekedar hadir bukan takdir, hanya momen bukan komitmen.',
'perasaan yang terbang, tidak selalu berujung mendarat dengan selamat. -Satzz',
'bertemu denganmu adalah hal yg tak pernah terduga, dan kepergian mu pun sebaliknya. -Satzz',
'Aku orang yang datang di masa depan mu, tapi kenapa kamu masih mencintai masa lalu mu. -Satzz',
'Terkadang waktu yang singkat memiliki kenangan yang hebat. -Satzz',
'Nyatanya kamu menghilang lebih dulu dibandingkan senja yang kita tunggu. -Satzz',
'Pada akhirnya, aku mau menemanimu, sampai nanti akhirnya kamu ditemani oleh seseorang yang kamu mau.',
'setia itu sederhana hanya orang hebat yang bisa melakukannya. -Satzz',
'Jangan datang pada seseorang yang belum selesai dengan masa lalunya.\nHingga saatnya dia berucap "kamu adalah pengisi, bukan pengganti". -Satzz',
'mencintai orang baru yang belum selesai dengan masa lalunya adalah patah hati yang disengajakan',
'level tertinggi mencintai seseorang yaitu melihat dia bahagia meskipun bersama orang lain,\ndan level tertinggi berbohong adalah kalimat di atas.',
'lupakanlah aku dan hiduplah dengan bebas. -eren jaeger',
'mencintai namun tak dicintai adalah seni sederhana melukiskan sebuah luka',
'aku pernah menjadi masalalu yang kalah dengan orang baru sekarang aku orang baru yang kalah dengan masalalu',
'lebih baik terjebak diantara hujan,dripa terjebak di antara rasa nyaman namun hanya di anggap sebatas teman',
'aku juga ingin dicintai hebat olehmu, sama seperti kamu yang mencintai hebat masalalumu.',
'dari sekian banyak permainan yang ada, kenapa hatiku yang kamu permainankan wahai nona.',
'aku sebut kamu "bulan", karena kamu sangat mencintai objek langit tersebut. tapi nyatanya, sulit bagiku menggapaimu. kamu terlalu jauh. -Satzz',
'Datang Karena Penasaran, Pergi Tanpa Sepatah Ucapan.',
'Aku kira break kita bakal jadi sebuah penundaan sementara\nTernyata selamanya.',
'Dan bersabarlah engkau sesungguhnya janji Allah itu benar adanya\nQS Ar - Rum ayat 60',
'Jika ego dibalas ego maka perpisahanlah yang akan menjadi pemenangnya.',
'Kenapa harus ada matahari tenggelam dihari yang sempurna, -Patrick Star',
'jangan mengeluh ketika kopimu dingin, karena dia pernah hangat tapi kamu abaikan'
]
let res = await fetchJson(`https://api.betabotz.eu.org/api/asupan/tiktok?query=xxgirls02&apikey=IOlkNUoN`)  
await reply(`${pickRandom(satzz_lagi_galau)}`)
await Satzz.sendMessage(from, {audio: await getBuffer(res.result.data.music.play), ptt:true, wavefrom: new Uint8Array(64), mimetype: 'audio/mpeg', contextInfo:{mentionedJid:[m.sender],"externalAdReply": {"showAdAttribution": true,"renderLargerThumbnail": true,"title": `⇆ㅤ ||◁ㅤ❚❚ㅤ▷||ㅤ ↻`,"body": `   ━━━━⬤────────── `,"description": 'Simple WhatsApp Bot',"containsAutoReply": true,"mediaType": 1, "thumbnail": thumb,"mediaUrl": sgc}}})
}
break
case "motivasi":{
let motivasi = []
reply()
}
case "asupan":{
if (!isPremium) return reply('premium user only!')
let kueri = await pickRandom(['kkara000','initokyolagii','amnddiah_','nylasetilia','vicidior02','gabagtha'])
let res = await fetchJson(`https://api.betabotz.eu.org/api/asupan/tiktok?query=${kueri}&apikey=IOlkNUoN`)  
Satzz.sendMessage(from, {video: await getBuffer(res.result.data.video)},{quoted:setQuoted})
}
break
case "senja":{
let res = await fetchJson(`https://api.betabotz.eu.org/api/asupan/tiktok?query=sandhya.__7&apikey=IOlkNUoN`)  
Satzz.sendMessage(from, {video: await getBuffer(res.result.data.video)},{quoted:setQuoted})
}
break



//━━━━━━━━━━━━━━━[ AI ]━━━━━━━━━━━━━━━━━//
case "ai":{
if (!q) return reply("input query!")
if (!isPremium && db.data.users[m.sender].limit < 1) return reply(mess.limit);
react('⏳')
await fetchJson(`https://api.betabotz.eu.org/api/search/openai-logic?text=${q}&logic=aku%20siesta%20ai%20yang%20dibuat%20oleh%20satganzdevs%20namaku%20siesta%20natsugani&apikey=IOlkNUoN`).then(res => reply(res.message))
react('')
if (!isPremium) db.data.users[m.sender].limit -= 1; 
}
break
case "img":{
if (!q) return reply("input prompt!")
if (!isPremium && db.data.users[m.sender].limit < 1) return reply(mess.limit);
react('⏳')
Satzz.sendImage(from, `https://image.pollinations.ai/prompt/${q}?seed=${new Date()}`, 'done', m)
if (!isPremium) db.data.users[m.sender].limit -= 1; 
}
break



//━━━━━━━━━━━━━━━[ INFO ]━━━━━━━━━━━━━━━━━\\
case "runtime":{
reply(runtime(process.uptime()));
}
break;
case "speed":{
const timestampp = speed();
const latensi = speed() - timestampp
reply(`Speed: ${latensi.toFixed(4)} Second`)
}
break
case "ram":{
const os = require('os');
let total = (os.totalmem() / (1024 * 1024 * 1024)).toFixed(0)
let free = (os.freemem() / (1024 * 1024 * 1024)).toFixed(0)
let used = total-free
let persen = ((used / total) * 100).toFixed(0)
reply(`RAM yang digunakan: ${persen} %`)
}
break
case "ping": {
const used = process.memoryUsage()
let timestamp = speed()
let latensi = speed() - timestamp
let neww = performance.now()
let oldd = performance.now()
let respon = `
Kecepatan Respon ${latensi.toFixed(4)} _Second_\n 
Info Server
RAM: ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}\n
_NodeJS Memory Usaage_
${Object.keys(used).map((key, _, arr) => `${key.padEnd(Math.max(...arr.map(v=>v.length)),' ')}: ${formatp(used[key])}`).join('\n')}\n
`.trim()
reply(respon)
}
break
case "owner":{
await react('⏳')
const more = String.fromCharCode(8206)
const readmore = more.repeat(4001) 
const loli = [[`6281316701742@s.whatsapp.net`, `${await Satzz.getName('6281316701742@s.whatsapp.net')}`,`${botname} Developers`,`im a red flag 🚩`],[`${botNumber.split('@')[0]}`, `${botname}`,`WhatsApp Bot`, `⚠️ Please Don't Spam Block or Banned`]]
const sentMsg = await Satzz.sendContactArray(m.chat, loli, m)
Satzz.sendMessage(from, { text: `more info about my owners?\n${readmore}\nINSTAGRAM: https://instagram.com/kurniawan_satria__\nGITHUB: https://github.com/SatganzDevs\n`, contextInfo: {externalAdReply: {title: week + ` ` + calender, thumbnail: await getBuffer(`https://miro.medium.com/v2/resize:fit:1358/1*9h9YpiykxheK8j8qh4gM4w.png`), mediaType: 1, renderLargerThumbnail: true}}},{ quoted: sentMsg });
}
break;
case "menu":{
let { menuList } = require("./help");
let res = await fetchJson(`https://api.betabotz.eu.org/api/asupan/tiktok?query=__amiiiiii15&apikey=IOlkNUoN`)
await react('⏳')
await Satzz.sendMessage(from, {text: await menuList(m.sender), contextInfo: { mentionedJid: [m.sender],externalAdReply: { showAdAttribution: true, title: `⌜ ${wm} ⌟`, body: ucapanWaktu, sourceUrl: sgc,thumbnail: thumb,mediaType: 1,renderLargerThumbnail: true}}}, { quoted: setQuoted });
await Satzz.sendMessage(from, {audio: await getBuffer(res.result.data.music.play), ptt: true, wavefrom: new Uint8Array(64), mimetype: 'audio/mpeg', contextInfo:{externalAdReply:{showAdAttribution:true, body: `${week}, ${calender}`, mediaType: 1, thumbnail: thumb}}})
await react('')
}
break;
case "allmenu": case "menuall":{
react('⏳')
let { allMenu } = require("./help");Satzz.sendMessage(from, {text: await allMenu(), contextInfo: { mentionedJid: [m.sender],externalAdReply: { showAdAttribution: true, title: `⌜ ${wm} ⌟`, body: ucapanWaktu, sourceUrl: sgc,thumbnail: thumb,mediaType: 1,renderLargerThumbnail: true}}}, { quoted: setQuoted });
react('')
}
break



//━━━━━━━━━━━━━━━[ DOWNLOADER ]━━━━━━━━━━━━━━━━━//
case "pinterestdl": case "pindl":{
if (!isPremium && db.data.users[m.sender].limit < 1) return reply(mess.limit);
if (!q) return reply('urlnya??')     
let res = await fetchJson(`https://api.satganzdevs.tech/api/pinterestdl?url=${q}`)
Satzz.sendFileUrl(from, res.videoUrl, "", m)
if (!isPremium) db.data.users[m.sender].limit -= 1; 
}
break
case "spotifydl":{
if (!isPremium && db.data.users[m.sender].limit < 1) return reply(mess.limit);
if (!q) return reply(`example use : ${command} https://open.spotify.com/track/3e1rs346dsDDwpqTRGlRZR?si=d92392fad4684017`)
var spottydl = require("spottydl")
reply(mess.wait)
await spottydl.getTrack(q).then(async results => {
let texts =`⟮ _~SPOTIFY DOWNLOADER~_ ⟯\n
⭔ Title : ${results.title}
⭔ Artist : ${results.artist}
⭔ Year : ${results.year}
⭔ Album : ${results.album}
⭔ Id : ${results.id}\n
NOTE : Kami Sedang memproses audio, mohon bersabar`
Satzz.sendMessage(from, {contextInfo:{externalAdReply:{showAdAttribution: true,title: results.title,body: results.artist,mediaType: 1,mediaUrl: q,thumbnail: await getBuffer(results.albumCoverURL),sourceUrl: q,renderLargerThumbnail: true}}})
await reply(texts)
let aud = await spottydl.downloadTrack(results, `./`)
Satzz.sendMessage(m.chat, { audio: {url: aud[0].filename}, mimetype: "audio/mpeg", ptt: false,},{ quoted: setQuoted })
});    
if (!isPremium) db.data.users[m.sender].limit -= 1; 
}
break
case "ytmp3":{
if (!isPremium && db.data.users[m.sender].limit < 1) return reply(mess.limit);
if (!q) return m.reply(`Example : ${command} https://youtube.com/watch?v=PtFMh6Tccag%27`);
reply(global.mess.wait)
const url = q;
let { toAudio } = require("../lib/converter");
let audio = await toAudio(await getBuffer(`https://api.satganzdevs.tech/api/yta?apikey=satria&url=${url}`), 'mp4')
Satzz.sendMessage(m.chat, {audio: audio, mimetype: "audio/mpeg", ptt: false},{ quoted: m })
if (!isPremium) db.data.users[m.sender].limit -= 1; 
}
break;
case "ytmp4":{
if (!isPremium && db.data.users[m.sender].limit < 1) return reply(mess.limit);
if (!q) return m.reply(`Example : ${command} https://youtube.com/watch?v=PtFMh6Tccag%27`);
reply(global.mess.wait);
const url = q;
let mp4File = getRandom(".mp4");
ytdl(url).pipe(fs.createWriteStream(mp4File)).on("finish", async () => {
Satzz.sendMessage(m.chat, { video: fs.readFileSync(mp4File), mimetype: "video/mp4" },{ quoted: setQuoted });
})
if (!isPremium) db.data.users[m.sender].limit -= 1; 
}di
break;
case "tiktokmp3": case "tiktokaudio": case "tiktokmusic": {
if (!isPremium && db.data.users[m.sender].limit < 1) return reply(mess.limit);
reply(`mohon tunggu sebentar...\n\n_note: fitur ini mengambil audio dari sound tiktok, yang di gunakan di video/foto tiktok._`)
try {
const { TiktokDownloader } = require("@tobyg74/tiktok-api-dl")
let r = await TiktokDownloader(budy, {version: "v3"})
let result = r.result
Satzz.sendMessage(m.chat, { audio: await getBuffer(result.music), mimetype: "audio/mpeg"},{ quoted: setQuoted });
} catch (error) {
console.log(error);
reply("error");
} 
if (!isPremium) db.data.users[m.sender].limit -= 1; 
}
break;
case "scdl": case "souncloud": case "soundclouddl":{
if (!isPremium && db.data.users[m.sender].limit < 1) return reply(mess.limit);
react('⏳')
let { soundcloud } = require("../lib/skrep") 
let r = await soundcloud(q)
Satzz.sendMessage(from, {contextInfo:{ externalAdReply:{title: r.judul, body: r.download_count, previewType: "PHOTO", mediaType: "IMAGE", thumbnail: await getBuffer(r.thumb), renderLargerThumbnail:true}}, audio: { url: r.link }, mimetype: "audio/mpeg", ptt: false, mtype: 'audioMessage'},{ quoted: setQuoted }); 
if (!isPremium) db.data.users[m.sender].limit -= 1; 
}
break;



//━━━━━━━━━━━━━━━[ CONVERTER ]━━━━━━━━━━━━━━━━━//
case "emojimix":{
let [emoji1, emoji2] = q.split`+`;
if (!emoji1) throw `Example : ${prefix + command} 😅+🤔`;
if (!emoji2) throw `Example : ${prefix + command} 😅+🤔`;
let anu = await fetchJson(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}`);
for (let res of anu.results) {
await Satzz.sendImageAsSticker(m.chat, res.url, m, {packname: global.packname,author: global.author, ios_app_store_link: "https://wa.me/6281316701742", android_play_store_link : "https://wa.me/6281316701742"});
}}
break;
case "emojimix2":{
if (!q) throw `Example : ${prefix + command} 😅`;
let anu = await fetchJson(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(q)}`);
for (let res of anu.results) {
Satzz.sendImageAsSticker(m.chat, res.url, m, {packname: global.packname,author: global.author,});
}}
break;
case "qc": {
if (!isPremium && db.data.users[m.sender].limit < 1) return reply(mess.limit);
if (!quoted){
const getname = await Satzz.getName(mentionUser[0])
const json = {"type": "quote","format": "png","backgroundColor": "#FFFFFF","width": 512,"height": 768,"scale": 2,"messages": [{"entities": [],"avatar": true,"from": {"id": 1,"name": getname,"photo": {"url": ppuser}},"text": quotedMsg.chats,"replyMessage": {}}]};
await axios.post('https://bot.lyo.su/quote/generate', json, {headers: {'Content-Type': 'application/json'}}).then(res => {
const buffer = Buffer.from(res.data.result.image, 'base64')
Satzz.sendImageAsSticker(from, buffer, m, { packname: global.packname, author: global.author }) 
});
} else if (q) {
const json = {"type": "quote","format": "png","backgroundColor": "#FFFFFF","width": 512,"height": 768,"scale": 2,"messages": [{"entities": [],"avatar": true,"from": {"id": 1,"name": pushname,"photo": {"url": ppuser}},"text": q,"replyMessage": {}}]};
await axios.post('https://bot.lyo.su/quote/generate', json, {headers: {'Content-Type': 'application/json'}}).then(res => {
const buffer = Buffer.from(res.data.result.image, 'base64')
Satzz.sendImageAsSticker(from, buffer, m, { packname: global.packname, author: global.author }) 
});
} else {
reply(`> Kirim perintah ${prefix+command} text atau reply pesan dengan perintah ${prefix+command}`)
}
if (!isPremium) db.data.users[m.sender].limit -= 1;
}
break
case "toimg":
case "toimage":{
if (!isPremium && db.data.users[m.sender].limit < 1) return reply(mess.limit);
if (!/webp/.test(mime)) return reply(`Reply sticker dengan caption *${prefix + command}*`);
react('⏳')
try {
let { webp2mp4File } = require("../lib/uploader");
let medias = await Satzz.downloadAndSaveMediaMessage(qmsg);
let ran = await webp2mp4File(medias);
Satzz.sendMessage(m.chat, { video: await getBuffer(ran.result) }, { quoted: m });
} catch {
let media = await Satzz.downloadAndSaveMediaMessage(qmsg);
let ran = await getRandom(".png");
exec(`ffmpeg -i ${media} ${ran}`, (err) => {
fs.unlinkSync(media);
if (err) throw err;
let buffer = fs.readFileSync(ran);
Satzz.sendMessage(m.chat, { image: buffer, contextInfo }, { quoted: m });
});
} 
if (!isPremium) db.data.users[m.sender].limit -= 1; 
}
break;
case "tomp3": case "toaudio":{
if (!isPremium && db.data.users[m.sender].limit < 1) return reply(mess.limit);
if (!/video/.test(mime) && !/audio/.test(mime)) return reply(`Kirim/Reply Video/Audio Yang Ingin DijaSatzzn Audio Dengan Caption ${prefix + command
}`);
if (!q) return reply(`masukan nama audio!, contoh : .${command} kretek"`)
react('⏳')
const NodeID3 = require('node-id3');
let media = await Satzz.downloadMediaMessage(qmsg);
let { toAudio } = require("../lib/converter");
let audio = await toAudio(media, "mp4");
let buffer = Buffer.from(audio)
let tags = { title: q, artist: `${global.author}`, album: 'SIESTA - MD', APIC: './media/thumb.jpg', year: 2024 }
let success = NodeID3.write(tags, buffer);
await Satzz.sendMessage(m.chat, { audio: success, mimetype: "audio/mpeg" },{ quoted: m }); 
react('')
if (!isPremium) db.data.users[m.sender].limit -= 1; 
}
break;
case "tovn":{
if (!/video/.test(mime) && !/audio/.test(mime)) return reply(`Reply Video/Audio Yang Ingin DijaSatzzn VN Dengan Caption ${prefix + command}`);
if (!isPremium && db.data.users[m.sender].limit < 1) return reply(mess.limit);
react('⏳')
let media = await Satzz.downloadMediaMessage(qmsg);
let { toPTT } = require("../lib/converter");
let audio = await toPTT(media, "mp4");
Satzz.sendMessage(m.chat, {audio: audio, ptt: true, waveform: new Uint8Array(64), mimetype: "audio/mpeg", },{ quoted: setQuoted }) 
if (!isPremium) db.data.users[m.sender].limit -= 1; 
}
break;
case "togif":{
if (!/webp/.test(mime)) return reply(`Reply stiker dengan caption *${prefix + command}*`);
if (!isPremium && db.data.users[m.sender].limit < 1) return reply(mess.limit);
react('⏳')
let { webp2mp4File } = require("../lib/uploader");
let media = await Satzz.downloadAndSaveMediaMessage(qmsg);
let webpToMp4 = await webp2mp4File(media);
await Satzz.sendMessage(m.chat, { video: {url: webpToMp4.result, caption: "Convert Webp To Video",streamingSidecar: new Uint8Array(300),},gifPlayback: true, contextInfo },{ quoted: setQuoted });
await fs.unlinkSync(media) 
if (!isPremium) db.data.users[m.sender].limit -= 1; 
}
break;
case "toptv":{
if (!m.quoted) return reply(`Balas Video Dengan Caption ${prefix + command}`);
if (!isPremium && db.data.users[m.sender].limit < 1) return reply(mess.limit);
if (/video/.test(mime)) {
react('⏳')
var ppt = m.quoted;
var ptv = generateWAMessageFromContent(from, proto.Message.fromObject({ ptvMessage: ppt }), { userJid: from, quoted: m });
Satzz.relayMessage(from, ptv.message, { messageId: ptv.key.id }) }
if (!isPremium) db.data.users[m.sender].limit -= 1; 
}
break;
case "sticker": case "stiker": case "s":{
if (/image/.test(mime)) {
react('⏳')
let media = await Satzz.downloadMediaMessage(qmsg);
Satzz.sendImageAsSticker(m.chat, media, m, {pack: global.packname, author: global.author});
} else if (/video/.test(mime)) {
react('⏳')
let media = await Satzz.downloadMediaMessage(qmsg);
let encmedia = await Satzz.sendVideoAsSticker(m.chat, media, m, {pack: global.packname, author: global.author});
await fs.unlinkSync(encmedia);
} else reply(`Kirim/reply gambar/video/gif dengan caption ${prefix + command}\nDurasi Video/Gif 1-9 Detik`);
}
break;
case "swm": case "take": case "wm":{
if (!isPremium) return reply(global.mess.premium)
if (!q) return reply('input packname|author')
if (!/webp/.test(mime)) return reply(`Reply sticker dengan caption *${prefix + command}*`);
react('⏳')
try {
let { webp2mp4File } = require("../lib/uploader");
let medias = await Satzz.downloadAndSaveMediaMessage(qmsg);
let ran = await webp2mp4File(medias);
Satzz.sendVideoAsSticker(m.chat, ran.result, m, {
packname: q.split('|')[0],
author: q.split('|')[1],
});
} catch {
let media = await Satzz.downloadAndSaveMediaMessage(qmsg);
let ran = await getRandom(".png");
exec(`ffmpeg -i ${media} ${ran}`, (err) => {
let buffer = fs.readFileSync(ran);
Satzz.sendImageAsSticker(m.chat, buffer, m, {
packname: q.split('|')[0],
author: q.split('|')[1],
});
});
}
}
break;
case "smeme":{
if (!q) return reply(`Balas Image Dengan Caption ${prefix + command}`);
if (!quoted) return reply(`Balas Image Dengan Caption ${prefix + command}`);
if (/image/.test(mime)) {
mee = await Satzz.downloadAndSaveMediaMessage(quoted);
mem = await uptotelegra(mee);
let kaytid 
if (q.includes("|")) {
kaytid = await getBuffer(`https://api.memegen.link/images/custom/${q.split("|")[0]}/${q.split("|")[1]}.png?background=${mem}`);
} else kaytid = await getBuffer(`https://api.memegen.link/images/custom/-/${q}.png?background=${mem}`);
Satzz.sendImageAsSticker(m.chat, kaytid, m, {packname: global.packname,author: global.author,isAvatar:true});
} else return reply("hanya bisa membuat smeme dari foto");
}
break;



//━━━━━━━━━━━━━━━[ TOOLS ]━━━━━━━━━━━━━━━━━//
case "toanime":{
if (!isPremium) return reply(mess.premium)
if (/image/.test(mime)) {
let { toanime } = require('../lib/toanime')
await react('⏳')
let mdi = await Satzz.downloadMediaMessage(qmsg)
let media = await toanime(mdi)
Satzz.sendMessage(from, {image: media, contextInfo},{quoted:m})
} else reply('kiirim reply foto dengan caption .toanime')
}
break
case "ssweb":{
if (!isPremium && db.data.users[m.sender].limit < 1) return reply(mess.limit);
if (!q) return reply('urlnya?')
reply(mess.wait)
let {ssweb} = require("../lib/scrapes")
let res = await ssweb(q)
Satzz.sendMessage(from, {image: res.result, caption: 'nih'},{quoted:m})
if (!isPremium) db.data.users[m.sender].limit -= 1; 
}
break
case "stickersearch":{
if (!isPremium && db.data.users[m.sender].limit < 1) return reply(mess.limit);
if (!q) return reply(`contoh : .${command} cat`)
let { stickersearch } = require("../lib/scrapes")
reply(mess.wait)
let res = await stickersearch(q)
for (let satria of res.sticker) Satzz.sendImageAsSticker(from, satria, m, {pack: global.packname, author: global.author})
if (!isPremium) db.data.users[m.sender].limit -= 1; 
}
break
case "tr": case "translate": {
if (!quoted) return reply('balas text yang ingin di translate! contoh : .tr id')
if (!quoted.text) return reply('pesan yang kamu balas tidak mengandung teks.')
let translate = await fetchJson(`https://api.satganzdevs.tech/api/translate?apikey=satria&text=${m.quoted.text}&lang=${q}`)
reply(translate.result)
}
break
case "earrape": 
case "bass": 
case "blown": 
case "deep":  
case "fast": 
case "fat": 
case "nightcore": 
case "reverse": 
case "robot": 
case "slow": 
case "smooth": 
case "tupai":
try {
let set
if (/bass/.test(command)) set = '-af equalizer=f=54:width_type=o:width=2:g=20'
if (/blown/.test(command)) set = '-af acrusher=.1:1:64:0:log'
if (/deep/.test(command)) set = '-af atempo=4/4,asetrate=44500*2/3'
if (/earrape/.test(command)) set = '-af volume=12'
if (/fast/.test(command)) set = '-filter:a "atempo=1.63,asetrate=44100"'
if (/fat/.test(command)) set = '-filter:a "atempo=1.6,asetrate=22100"'
if (/nightcore/.test(command)) set = '-filter:a atempo=1.06,asetrate=44100*1.25'
if (/reverse/.test(command)) set = '-filter_complex "areverse"'
if (/robot/.test(command)) set = '-filter_complex "afftfilt=real=\'hypot(re,im)*sin(0)\":imag=\'hypot(re,im)*cos(0)\":win_size=512:overlap=0.75"'
if (/slow/.test(command)) set = '-filter:a "atempo=0.7,asetrate=44100"'
if (/smooth/.test(command)) set = '-filter:v "minterpolate=\'mi_mode=mci:mc_mode=aobmc:vsbmc=1:fps=120\'"'
if (/tupai/.test(command)) set = '-filter:a "atempo=0.5,asetrate=65100"'
if (/audio/.test(mime)) {
if (!isPremium && db.data.users[m.sender].limit < 1) return reply(mess.limit);
reply(global.mess.wait)
let media = await Satzz.downloadAndSaveMediaMessage(quoted)
let ran = getRandom('.mp3')
exec(`ffmpeg -i ${media} ${set} ${ran}`, (err, stderr, stdout) => {
fs.unlinkSync(media)
if (err) return reply(err)
let buff = fs.readFileSync(ran)
Satzz.sendMessage(m.chat, { audio: buff, mimetype: 'audio/mpeg' }, { quoted : m })
fs.unlinkSync(ran)
})
} else reply(`Balas audio yang ingin diubah dengan caption *${prefix + command}*`)
} catch (e) {
reply(e)
}
if (!isPremium) db.data.users[m.sender].limit -= 1; 
break
case "ytsearch":
case "yts":{
if (!isPremium && db.data.users[m.sender].limit < 1) return reply(mess.limit);
if (!q) return reply(`Example : ${prefix + command} story wa anime`);
let {key} = await Satzz.sendMessage(from, { text: 'procces...' },{quoted:m})
let yts = require("yt-search");
let search = await yts(q);
let teks = "YouTube Search\n\n Result From " + q + "\n\n";
let no = 1;
for (let i of search.all) {teks += `⭔ No : ${no++}\n⭔ Type : ${i.type}\n⭔ Video ID : ${i.videoId}\n⭔ Title : ${i.title}\n⭔ Views : ${i.views}\n⭔ Duration : ${i.timestamp}\n⭔ Upload At : ${i.ago}\n⭔ Author : \n⭔ Url : ${i.url}\n\n─────────────────\n\n` }
await sleep(2000)
Satzz.sendMessage(m.chat, {text: teks, edit: key });
if (!isPremium) db.data.users[m.sender].limit -= 1; 
}
break;
case "play":
if (!isPremium && db.data.users[m.sender].limit < 1) return reply(mess.limit);
if (!q) return reply(`Example : ${prefix + command} Patience - Take That`);
react('⏳')
const NodeID3 = require('node-id3');
const yts = require("yt-search");
const { toAudio } = require("../lib/converter");
try {
let search = await yts(`lagu ${q}`);
let anu = search.videos[0];
Satzz.sendMessage(m.chat, {contextInfo: {contextInfo,externalAdReply: {showAdAttribution: true,title: `${anu.title}`,body: `${week} , ${calender}`,mediaType: 2,renderLargerThumbnail: true,thumbnail: await getBuffer(anu.thumbnail),mediaUrl: anu.url,sourceUrl: anu.url}}, text: `*[ YOUTUBE PLAY ]*\n\n◯ TITLE: ${anu.title}\n◯ DESC: ${anu.description}\n\n_audio sedang di proses.._`}, { quoted: m });
let mp3File = getRandom(".mp3");
ytdl(anu.url, { filter: "audioonly" }).pipe(fs.createWriteStream(mp3File)).on("finish", async () => {
let audio = await toAudio(fs.readFileSync(mp3File))
let buffer = Buffer.from(audio)
let tags = {title: `${anu.title}`, artist: `${global.author}`, album: 'SIESTA - MD',APIC: './media/thumb.jpg',year: 2024}
let success = NodeID3.write(tags, buffer);
await Satzz.sendMessage(m.chat, { audio: success, mimetype: "audio/mpeg", ptt: false, contextInfo:{externalAdReply: {showAdAttribution: true, title: `▷ ⬤───────────────`, body: `click here to play music `,description: 'Now Playing ....',mediaType: 2,thumbnailUrl: anu.thumbnail,mediaUrl: anu.url}}}, { quoted: m });
react('')
});
} catch (err) {
console.log(err);
}
if (!db.data.users[m.sender].premium) 
db.data.users[m.sender].limit -= 1;
break;
case "tohd":
case "remini":
case "hd": {
if (!isPremium && db.data.users[m.sender].limit < 1) return reply(mess.limit);
if (/image/.test(mime)) {
reply(mess.wait)
const { remini } = require('../lib/remini');
let media = await Satzz.downloadMediaMessage(qmsg);
let resultan = await remini(media, "enhance");
await Satzz.sendMessage(m.chat, { image: resultan, caption: "ɴɪʜ ᴋᴀᴋ ʜᴀꜱɪʟɴʏᴀ (*^ ‿ <*)♡", mimetype: "image/jpeg", annotations: global.annotations,contextInfo },{ quoted: setQuoted });
} else return reply('Bot Hanya Bisa Enhance Image/gambar.') 
if (!isPremium) db.data.users[m.sender].limit -= 1; 
}
break;
case "ppcp":
case "cp":
case "couple":{
if (!isPremium && db.data.users[m.sender].limit < 1) return reply(mess.limit);
react('⏳')
let anu = await fetchJson("https://raw.githubusercontent.com/SatganzDevs/database/main/kopel.json");
let random = pickRandom(anu)
await Satzz.sendMessage(m.chat, { image: { url: random.male }, caption: `𝘊𝘰𝘸𝘰𝘯𝘺𝘢`, contextInfo},{ quoted: m });
await Satzz.sendMessage(m.chat,{ image: { url: random.female }, caption: `𝘊𝘦𝘸𝘦𝘯𝘺𝘢`, contextInfo},{ quoted: m});
if (!isPremium) db.data.users[m.sender].limit -= 1; 
}
break;
case "lyrics":
case "lirik":{
if (!isPremium && db.data.users[m.sender].limit < 1) return reply(mess.limit);
if (!q) return reply('input query!');
let res = await Scraper.lyricsv2(q);
let {key} = await Satzz.sendMessage(from, { text: 'procces...' },{quoted:m})
let teks =`
ℹ️ TITLE: ${res.title}
👑 AUTHOR: ${res.author}
📌 LYRICS: ${res.lyrics}
`
await sleep(2000)
await Satzz.sendMessage(from, {text: teks, edit:key});
if (!isPremium) db.data.users[m.sender].limit -= 1; 
}
break;
case "gimage": case "googleimage":{
if (!isPremium && db.data.users[m.sender].limit < 1) return reply(mess.limit);
if (!q) return reply('masukan query!, contoh penggunaan : .gimage loli')  
react('⏳')
let res = await fetchJson(`https://web.zeeoneofc.my.id/api/search/google-image?query=${q}&apikey=Alphabot`)
let sentImages = 0;
for (let i = 0; i < res.data.length; i++) {
if (sentImages >= 10) break;
Satzz.sendImage(from, res.data[i], `🌐 URL : ${res.data[i]}`, { contextInfo });
sentImages++;
}
if (!isPremium) db.data.users[m.sender].limit -= 1; 
}
break
case "pin": case "pinterest": {
if (!isPremium && db.data.users[m.sender].limit < 1) return reply(mess.limit);
if (!q) return reply(global.mess.query);
react('⏳')
if (q.split("|")[1] === "asSticker") {
await fetchJson('https://api.satganzdevs.tech/api/pinterest?apikey=satria&query=' + q.split("|")[0]).then(async(res) => {
for ( let ai of res) {
let kaytid = await getBuffer(ai) 
Satzz.sendImageAsSticker(m.chat, kaytid, m, { packname: global.packname, author: global.author, isAvatar: true });
await sleep(1000)
}});
} else {
let res = await fetchJson('https://api.satganzdevs.tech/api/pinterest?apikey=satria&query=' + q)
let sentImages = 0;
for (let i of res) {
if (sentImages >= 10) break;
Satzz.sendMessage(m.chat, { image: { url: i.replace("736x", "originals") }, contextInfo });
sentImages++;
}
if (!isPremium) db.data.users[m.sender].limit -= 1; 
}
}
break;



//━━━━━━━━━━━━━━━[ GROUP ]━━━━━━━━━━━━━━━━━//
case "ban":
case "banned":{
if (!isAdmins && !isOwner) return reply('hanya admin dan owner') 
if (!quoted) return reply('balas pesan target!')
let alasan = q 
if (alasan == undefined) alasan = "Tanpa alasan."
let Nomer = `${m.quoted.sender.split("@")[0]}`
if(_ban.check(Nomer, ban)) return reply("User sudah di ban sebelumnya")
let Name = await Satzz.getName(m.quoted.sender)
if ("6281316701742".includes(m.quoted.sender)) return reply("Tidak bisa membanned owner")
_ban.add(Name, calender, Nomer, alasan, ban)
reply(`Berhasil banned @${m.quoted.sender.split("@")[0]}`);
}
break
case "unban":
case "delban":
case "unbanned":{
if (!isAdmins && !isOwner) return reply('hanya admin dan owner')
if (!quoted) return reply('balas pesan target!')
let users = m.quoted.sender
let Nomer =`${users.split("@")[0]}`
if(!_ban.check(Nomer, ban)) return reply("User sudah di unban sebelumnya")
_ban.del(Nomer, ban)
reply(`Berhasil unbanned @${users.split("@")[0]}`);
}
break
case "listban":{
let banya = `*List Banned*\nJumlah : ${ban.length}\n\n`
ban.map(function(e, i){
banya +=(i+1)+`. Nomer : @${e.id}\n└▸ Tanggal : ${e.date}\n└▸ Alasan : ${e.reason} \n\n`
});
reply(banya)
}
break
case 'ceksider': case 'sider':{
if (!isAdmins && !isOwner) return r(mess.admin)
var lama = 86400000 * 7
const now = new Date().toLocaleString("en-US", {timeZone: "Asia/Jakarta"});
const milliseconds = new Date(now).getTime();
let member = groupMetadata.participants.map(v => v.id)
if (!q) { var pesan = "Harap aktif di grup karena akan ada pembersihan member setiap saat" } else { var pesan = q }
var sum
sum = member.length
var total = 0
var sider = []
for (let i = 0; i < sum; i++) {
let users = m.isGroup ? groupMetadata.participants.find(u => u.id == member[i]) : {}
if ((typeof global.db.data.users[member[i]] == 'undefined' || milliseconds * 1 - global.db.data.users[member[i]].lastseen > lama) && !users.isAdmin) {
if (typeof global.db.data.users[member[i]] !== 'undefined') {
} else {
total++
sider.push(member[i]) }}}
if (total == 0) return reply(`*Digrup ini tidak terdapat sider.*`) 
reply(`*${total}/${sum}* anggota grup *${groupName}* adalah sider dengan alasan :\n1. Tidak aktif selama lebih dari 7 hari\n2. Baru join tetapi tidak pernah nimbrung\n\n_“${pesan}”_\n\n*LIST SIDER :*\n${sider.map(v => '  ○ @' + v.replace(/@.+/, '' + typeof global.db.data.users[v] == "undefined" ? ' Sider ' : ' Off ' + msToDate(milliseconds * 1 - global.db.data.users[v].lastseen))).join('\n')}`)
}
const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)
function msToDate(ms) {
let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000)
let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24
let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
if (d == 0 && h == 0 && m == 0) { return "Baru Saja" } else { return [d, 'H ', h, 'J '].map(v => v.toString().padStart(2, 0)).join('') }}
break
case "antilink":{
if (!isAdmins) return reply(global.mess.admin)
if (!isBotAdmins) return reply(global.mess.bodmin)
if (q == "on") {
db.data.chats[m.chat].antilink = true
reply(`sukses mengaktifkan ${command}`)
} else if (q == "off") {
db.data.chats[m.chat].antilink = false
reply(`sukses mematikan ${command}`)
} else reply("on/off?, contoh : antilink on")
}
break
case "antiviewonce":{
if (!isAdmins) return reply(global.mess.admin)
if (!isBotAdmins) return reply(global.mess.bodmin)
if (q == "on") {
db.data.chats[m.chat].antiviewonce = true
reply(`sukses mengaktifkan ${command}`)
} else if (q == "off") {
db.data.chats[m.chat].antiviewonce = false
reply(`sukses mematikan ${command}`)
} else reply("on/off?, contoh : antiviewonce on")
}
break
case "antidelete":{
if (!isAdmins) return reply(global.mess.admin)
if (!isBotAdmins) return reply(global.mess.bodmin)
if (q == "on") {
db.data.chats[m.chat].antidelete = true
reply(`sukses mengaktifkan ${command}`)
} else if (q == "off") {
db.data.chats[m.chat].antidelete = false
reply(`sukses mematikan ${command}`)
} else reply("on/off?, contoh : antidelete on")
}
break
case "nsfw":{
if (!isAdmins) return reply(global.mess.admin)
if (!isBotAdmins) return reply(global.mess.bodmin)
if (q == "on") {
db.data.chats[m.chat].nsfw = true
reply(`sukses mengaktifkan ${command}`)
} else if (q == "off") {
db.data.chats[m.chat].nsfw = false
reply(`sukses mematikan ${command}`)
} else reply("on/off?, contoh : nsfw on")
}
break
case "opentime":
if (!isAdmins) return reply(global.mess.admin)
if (!isBotAdmins) return reply(global.mess.bodmin)
if (args[1]=="detik") {
var timer = args[0]*`1000`
} else if (args[1]=="menit") {var timer = args[0]*`60000`
} else if (args[1]=="jam") {var timer = args[0]*`3600000`
} else if (args[1]=="hari") {var timer = args[0]*`86400000`
} else {return reply("*pilih:*\ndetik\nmenit\njam\n\n*contoh*\n10 detik")}
reply(`Open time ${q} dimulai dari sekarang`)
setTimeout( () => {
const open = `*Tepat waktu* grup dibuka oleh admin\n sekarang member dapat mengirim pesan`
Satzz.groupSettingUpdate(from, 'not_announcement')
reply(open)
}, timer)
break
case "closetime":
if (!isAdmins) return reply(global.mess.admin)
if (!isBotAdmins) return reply(global.mess.bodmin)
if (args[1]=="detik") {var timer = args[0]*`1000`
} else if (args[1]=="menit") {var timer = args[0]*`60000`
} else if (args[1]=="jam") {var timer = args[0]*`3600000`
} else if (args[1]=="hari") {var timer = args[0]*`86400000`
} else {return reply("*pilih:*\ndetik\nmenit\njam\n\n*contoh*\n10 detik")}
reply(`Close time ${q} dimulai dari sekarang`)
setTimeout( () => {
const close = `*Tepat waktu* grup ditutup oleh admin\nsekarang hanya admin yang dapat mengirim pesan`
Satzz.groupSettingUpdate(from, 'announcement')
reply(close)
}, timer)
break
case "open":{
if (!isAdmins) return reply(global.mess.admin)
if (!isBotAdmins) return reply(global.mess.bodmin)
Satzz.groupSettingUpdate(from, 'not_announcement')
}
break
case "close":{
if (!isAdmins) return reply(global.mess.admin)
if (!isBotAdmins) return reply(global.mess.bodmin)
Satzz.groupSettingUpdate(from, 'announcement')
}
break
case "del": case "delete": {
if (m.isGroup && !isAdmins) return reply(mess.admin)
let users = m.mentionedJid[0] ? m.mentionedJid : m.quoted ? [m.quoted.sender] : ""
if (!users) return reply("Reply pesan")
if (users == botNumber) {
Satzz.sendMessage(from, { delete: { remoteJid: from, fromMe: true, id: m.quoted.id, participant: users} })
} else if (users !== botNumber && isBotAdmins){
Satzz.sendMessage(from, { delete: { remoteJid: from, fromMe: false, id: m.quoted.id, participant: users } })
} 
}
break
case "kick":{
if (!m.isGroup) return reply(global.mess.group);
if (!isBotAdmins) return reply(global.mess.bodmin);
if (!isAdmins) return reply(global.mess.admin);
let users = m.mentionedJid[0] ? m.mentionedJid : m.quoted ? [m.quoted.sender] : [q.replace(/[^0-9]/g, "") + "@s.whatsapp.net"];
await Satzz.groupParticipantsUpdate(m.chat, users, "remove")
}
break;
case "add":{
if (!m.isGroup) return reply(global.mess.group);
if (!isBotAdmins) return reply(global.mess.bodmin);
if (!isAdmins) return reply(global.mess.admin);
let users = m.mentionedJid[0] ? m.mentionedJid : m.quoted ? [m.quoted.sender] : [q.replace(/[^0-9]/g, "") + "@s.whatsapp.net"];
let kode = await Satzz.groupInviteCode(m.chat)
try {
await Satzz.groupParticipantsUpdate(m.chat, users, "add")
} catch (e) {
await reply('di privasi!, mengirim groupinvite ke user.')
var groupInvite = generateWAMessageFromContent(users, proto.Message.fromObject({groupInviteMessage: {groupJid: m.chat,inviteCode: kode,inviteExpiration: 1711482804,groupName: groupMetadata.subject,caption: `@${senderNumber} mencoba mengajakmu untuk join ke : ${groupMetadata.subject}`,jpegThumbnail: await getBuffer(await Satzz.profilePictureUrl(m.chat, "IMAGE")),contextInfo:{mentionedJid:[m.sender]}}}),{ userJid: users, quoted: setQuoted });
await Satzz.relayMessage(users, groupInvite.message, {messageId: groupInvite.key.id});
}
}
break;
case "promote":{
if (!m.isGroup) return reply(global.mess.group);
if (!isBotAdmins) return reply(global.mess.bodmin);
if (!isAdmins) return reply(global.mess.admin);
let users = m.mentionedJid[0] ? m.mentionedJid : m.quoted ? [m.quoted.sender] : [q.replace(/[^0-9]/g, "") + "@s.whatsapp.net"];
await Satzz.groupParticipantsUpdate(m.chat, users, "promote").then((res) => reply("done")).catch((err) => reply("error"));
}
break;
case "demote":{
if (!m.isGroup) return reply(global.mess.group);
if (!isBotAdmins) return reply(global.mess.bodmin);
if (!isAdmins) return reply(global.mess.admin);
let users = m.mentionedJid[0] ? m.mentionedJid : m.quoted ? [m.quoted.sender] : [q.replace(/[^0-9]/g, "") + "@s.whatsapp.net"];
await Satzz.groupParticipantsUpdate(m.chat, users, "demote").then((res) => reply("done")).catch((err) => reply("error"));
}
break;
case "setnamegc": 
case "setsubject":{
if (!m.isGroup) return reply(global.mess.group);
if (!isBotAdmins) return reply(global.mess.bodmin);
if (!isAdmins) return reply(global.mess.admin);
if (!q) return reply("Text ?");
await Satzz.groupUpdateSubject(m.chat, q).then((res) => reply(global.mess.success)).catch((err) => reply("error"));
}
break;
case "setdesc":
case "setdesk":{
if (!m.isGroup) return reply(global.mess.group);
if (!isBotAdmins) return reply(global.mess.bodmin);
if (!isAdmins) return reply(global.mess.admin);
if (!q) return reply("Text ?");
await Satzz.groupUpdateDescription(m.chat, q).then((res) => reply(global.mess.success)).catch((err) => reply("error"));
}
break;
case "setppgroup":
case "setppgrup":
case "setppgc":{
if (!m.isGroup) return reply(global.mess.group);
if (!isAdmins) return reply(global.mess.admin);
if (!isBotAdmins) return reply(global.mess.bodmin);
if (!quoted) return reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`);
if (!/image/.test(mime) || /webp/.test(mime)) return reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`);
var mediz = await Satzz.downloadAndSaveMediaMessage(quoted, "ppgc.jpeg");
if (q == `/full`) {
var { img } = await generateProfilePicture(mediz);
await Satzz.query({tag: "iq", attrs: { to: m.chat, type: "set", xmlns: "w:profile:picture" }, content: [{ tag: "picture", attrs: { type: "image" }, content: img }]});
} else {
await Satzz.updateProfilePicture(m.chat, { url: mediz });
}
reply(`Sukses`);
}
break;
case "tagall":{
if (!m.isGroup) return reply(global.mess.group);
if (!isBotAdmins) return reply(global.mess.bodmin);
if (!isAdmins) return reply(global.mess.admin);
let teks = `══✪〘 *👥 Tag All* 〙✪══\n
➲ *Pesan : ${q ? q : "empty"}*\n\n`;
for (let mem of participants) {
teks += `⭔ @${mem.id.split("@")[0]}\n`;
}
Satzz.sendMessage(m.chat, { text: teks, mentions: participants.map((a) => a.id) },{ quoted: setQuoted });
}
break;
case "hidetag":{
if (!m.isGroup) return reply(global.mess.group);
if (!isBotAdmins) return reply(global.mess.bodmin);
if (!isAdmins) return reply(global.mess.admin);
Satzz.sendMessage(m.chat, { text: q ? q : "", mentions: participants.map((a) => a.id) },{ quoted: setQuoted });
}
break;
case "totag":{
if (!m.isGroup) return reply(global.mess.group);
if (!isBotAdmins) return reply(global.mess.bodmin);
if (!isAdmins) return reply(global.mess.admin);
if (!m.quoted) return reply(`Reply pesan dengan caption ${prefix + command}`);
Satzz.sendMessage(m.chat, {forward: m.quoted.fakeObj, mentions: participants.map((a) => a.id)});
}
break;
case "linkgroup":
case "linkgc":{
let response = await Satzz.groupInviteCode(m.chat);
reply(`https://chat.whatsapp.com/${response}\n\nGroup Link Of: ${groupMetadata.subject}`);
}
break;



//━━━━━━━━━━━━━━━[ FUN ]━━━━━━━━━━━━━━━━━//
case "jodohku":{
if (!m.isGroup) return reply(mess.group)
let member = participants.map(u => u.id)
let jodoh = member[Math.floor(Math.random() * member.length)]
reply(`Jodoh kamu adalah @${jodoh.split('@')[0]}`)
}
break
case "bisakah":{
if (!m.isGroup) return m.reply('Kusus group')
const bisakah = body.slice(0)
const bisa =['BISA','Tidak Bisa','Oh tentu saja bisa dong','Udah dari lahir dia bisa kaya gitu kak 😂˜„','Oh tentu saja tidak bisa','Wuih bisa bisa','Ga mao jawab ah lu wibu','Tentu saja bisa eh tapi boong awokawok ','Engga engga dia ga bisa','Enggaklah','Aku ga mao jawbab 😆™‚','Rahasia dong','Ulangi Tod gua ga paham','Mana gua tau anjir']
const keh = bisa[Math.floor(Math.random() * bisa.length)]
reply('*Pertanyaan : '+ bisakah +'*\n\n*Jawaban :* '+ keh)
}
break
case "bagaimanakah":{
if (!m.isGroup) return m.reply('Kusus group')
const bagaimanakah = body.slice(0)
const bagai =['Kita Kenal?','Nanya Terus deh','Tidak Tahu','Gua tabok boleh ?','Cari Aja Sendiri','Kurang Tahu','Mana Saya Tahu, Saya kan ikan','Hah kamu tanya sama aku trus aku tanya ke siapa dong','Whahahaha ga tau 😑']
const mana = bagai[Math.floor(Math.random() * bagai.length)]
reply('*Pertanyaan : '+bagaimanakah+'*\n\n*Jawaban :* '+ mana)
}
break
case "apakah":{
if (!m.isGroup) return m.reply('Kusus group')
const apakah = body.slice(0)
const apa =['iya dong jelas itu','Tidak lah','Oh tentu saja tidak','Ya mana saya tau kok tanya saya','Rahasia dong','ga usah di tanya emang udah kaya gitu dia','Au ah mending mandi','Bentar aku lagi berak','Knpa emang kamu suka sama dia yak ??','Haha mna mungkin 👻']
const kah = apa[Math.floor(Math.random() * apa.length)]
reply('*Pertanyaan : '+apakah+'*\n\n*Jawaban :* '+ kah)
}
break
case "kapankah":{
if (!m.isGroup) return m.reply('Kusus group')
const kapankah = body.slice(0)
const kapan =['Besok','Lusa','1 Hari Lagi','2 Hari Lagi','3 Hari Lagi','4 Hari Lagi','5 Hari Lagi','6 Hari Lagi','1 Bulan Lagi','2 Bulan Lagi','3 Bulan Lagi','4 Bulan Lagi','5 Bulan Lagi','6 Bulan Lagi','7 Bulan Lagi','8 Bulan Lagi','9 Bulan Lagi','10 Bulan Lagi','11 Bulan Lagi','1 Tahun lagi','2 Tahun lagi','3 Tahun lag0i','4 Tahun lagi','5 Tahun lagi','6 Tahun lagi','7 Tahun lagi','8 Tahun lagi','9 Tahun lagi','10 Tahun lagi']
const koh = kapan[Math.floor(Math.random() * kapan.length)]
reply('*Pertanyaan : '+kapankah+'*\n\n*Jawaban :* '+ koh)
}
break
case "cekwatak":{
const watak = body.slice(0)
const wa =['Penyayang','Pemurah','Pemarah','Pemaaf','Penurut','Baik','Baperan','Baik Hati','penyabar','UwU','top deh, pokoknya','Suka Membantu']
const tak = wa[Math.floor(Math.random() * wa.length)]
reply('Pertanyaan : *'+watak+'*\n\nJawaban : '+ tak)
}
break				
case "cekhobby":{
const hobby = body.slice(0)
const hob =['Memasak','Membantu Atok','Mabar','Nobar','Sosmedtan','Membantu Orang lain','Nonton Anime','Nonton Drakor','Naik Motor','Nyanyi','Menari','Bertumbuk','Menggambar','Foto fotoan Ga jelas','Maen Game','Berbicara Sendiri']
const by = hob[Math.floor(Math.random() * hob.length)]
reply('Pertanyaan : *'+hobby+'*\n\nJawaban : '+ by)
}
break
case "cekmeki":{
if (!m.isGroup) return reply(mess.group)
if (!q) return reply('tag temanmu!')
const persengayy = body.slice(0)
const gay = ["*Udah Ga Perawan:v*\n• Warna Item🙈\n• Bulu Lebat\n• Katanya Polos Ko Lima Jari Lolos Chuackk","*Masih Perawan*\n• Warna Pink🤤\n• Tidak Berbulu\n• Wah Yang ini Buat Owner Ku Aja😋","*Bjir Bau 😵‍💫*\n\n• Kang Colmek\n• Sangat Lebat:v\n• Ishh Sarang Jin Itu😵","*Masih Perawan*\n• Warna Putih Mati\n• Masih Polos\n• Sepertinya Anda Butuh Kehangatan Dari Owner ku🥸 ","*Meki nya Semu Coklat*\n • Korban Pemerkosaan 😑\n• Lu Sih Main Ma Kumpulan Cowo Sengklek\n• Sebaiknya Jan Terlalu Gegabah 🤧","*Normal Seperti Biasanya*\n• Wuanjay Ko Bulu Nya Pada Kriput🙈\n• Ternyata Oh Ternyata Kamu Suka Lesby🫤","*Bahaya Noh Gan*\n• Udah Kena Virus\n• Kalo wik wik Ntar Ke Patil Cowoknya\n😶‍🌫️Takut BerNanah Kelamin Ku ntarr😬","*Lah Ireng Amat bjirr*\n• Hati² Sama Ni Orang Beneran Dah\n• Jangankan Pria Hewan Pun Dia Layani🫣","*74%*\n*Astagfirullah Kabur Gan🏃🌬️*"]
const kl = gay[Math.floor(Math.random() * gay.length)]
reply('Hasil Dari: *'+persengayy+'*\n\nJawaban : '+kl)
}
break  
case "cekkontol":{
if (!m.isGroup) return reply(mess.group)
if (!q) return reply('Mana Nama?')	
if (q.includes("6281316701742")) return reply('besar inimah, kontol kuda')
const persenbucin = body.slice (0)
const bucin =
["Hadehh🤦\n[ Dah Item Bauk Lagi ishh🤮 ]","9%\n\nMasih Kecil Ini Mah Ketutup Ama bulu komt nya🗿 Ae","Nakk Masih Kecil","28%\n\nYoalahh hmm","34%\n\nMayan Lah","48%\n\nGatau","59%\n\nBiasa Kang Coli Mah Tityd nya Item🗿","apacoba\nKasian Mana Masih Muda","itu tityd apa terong"," Ya Ampun"]
const ehan = bucin[Math.floor(Math.random() * bucin.length)]
reply('cekkomtlo🗿: *'+persenbucin+'*\n\nJawaban : '+ ehan)
}
break 
case "wangy":{
if (!q) return reply('contoh wangy memek')
let qq = q.toUpperCase()
let teki = `${q.toUpperCase()} ${q.toUpperCase()} ${q.toUpperCase()} ❤️ ❤️ ❤️ WANGY WANGY WANGY WANGY HU HA HU HA HU HA, aaaah baunya rambut ${q.toUpperCase()} wangyy aku mau nyiumin aroma wangynya ${q.toUpperCase()} AAAAAAAAH ~ Rambutnya.... aaah rambutnya juga pengen aku elus-elus ~~ AAAAAH ${q.toUpperCase()} keluar pertama kali di anime juga manis ❤️ ❤️ ❤️ banget AAAAAAAAH ${q.toUpperCase()} AAAAA LUCCUUUUUUUUUUUUUUU............ ${q.toUpperCase()} AAAAAAAAAAAAAAAAAAAAGH ❤️ ❤️ ❤️apa ? ${q.toUpperCase()} itu gak nyata ? Cuma HALU katamu ? nggak, ngak ngak ngak ngak NGAAAAAAAAK GUA GAK PERCAYA ITU DIA NYATA NGAAAAAAAAAAAAAAAAAK PEDULI BANGSAAAAAT !! GUA GAK PEDULI SAMA KENYATAAN POKOKNYA GAK PEDULI. ❤️ ❤️ ❤️ ${q.toUpperCase()} gw ... ${q.toUpperCase()} di laptop ngeliatin gw, ${q.toUpperCase()} .. kamu percaya sama aku ? aaaaaaaaaaah syukur ${q.toUpperCase()} aku gak mau merelakan ${q.toUpperCase()} aaaaaah ❤️ ❤️ ❤️ YEAAAAAAAAAAAH GUA MASIH PUNYA ${q.toUpperCase()} SENDIRI PUN NGGAK SAMA AAAAAAAAAAAAAAH`
reply(teki)
}
break
case "genjot" :{
if (!q) return reply('Yang ingin di genjot sapa we')
let mamah = `${q.toUpperCase()} Buruan, panggil gue SIMP, ato BAPERAN. ini MURNI PERASAAN GUE. Gue pengen genjot bareng ${q.toUpperCase()}. Ini seriusan, suaranya yang imut, mukanya yang cantik, apalagi badannya yang aduhai ningkatin gairah gue buat genjot ${q.toUpperCase()}. Setiap lapisan kulitnya pengen gue jilat. Saat gue mau crot, gue bakal moncrot sepenuh hati, bisa di perut, muka, badan, teteknya, sampai lubang burit pun bakal gue crot sampai puncak klimaks. Gue bakal meluk dia abis gue moncrot, lalu nanya gimana kabarnya, ngrasain enggas bareng saat telanjang. Dia bakal bilang kalau genjotan gue mantep dan nyatain perasaannya ke gue, bilang kalo dia cinta ama gue. Gue bakal bilang balik seberapa gue cinta ama dia, dan dia bakal kecup gue di pipi. Terus kita ganti pakaian dan ngabisin waktu nonton film, sambil pelukan ama makan hidangan favorit. Gue mau ${q.toUpperCase()} jadi pacar, pasangan, istri, dan idup gue. Gue cinta dia dan ingin dia jadi bagian tubuh gue. Lo kira ini copypasta? Kagak cok. Gue ngetik tiap kata nyatain prasaan gue. Setiap kali elo nanya dia siapa, denger ini baik-baik : DIA ISTRI GUE. Gue sayang ${q.toUpperCase()}, dan INI MURNI PIKIRAN DAN PERASAAN GUE.`
reply(mamah)
}
break
case "perkosa":{
if (!q) return reply('siapa yang ingin kau perkosa')
let kondom = `GW BENAR-BENAR PENGEN JILAT KAKI *${q.toUpperCase()}*,GW PENGEN BANGET MENJILAT SETIAP BAGIAN KAKINYA SAMPAI AIR LIUR GW BERCUCURAN KAYAK AIR KERINGAT LALU NGENTOD DENGAN NYA SETIAP HARI SAMPAI TUBUH KITA MATI RASA, YA TUHAN GW INGIN MEMBUAT ANAK ANAK DENGAN *${q.toUpperCase()}* SEBANYAK SATU TIM SEPAK BOLA DAN MEMBUAT SATU TIM SEPAK BOLA LAINYA UNTUK MELAWAN ANAK-ANAK TIM SEPAK BOLA PERTAMA GW  YANG GW BUAT SAMA *${q.toUpperCase()}* GW PENGEN MASUK KE SETIAP LUBANG TUBUHNYA, MAU ITU LUBANG HIDUNG LUBANG MATA MAUPUN LUBANG BOOL, KEMUDIAN GW AKAN MANUSIA YANG TIDAK BISA HIDUP KALO GW GA ENTOD SETIAP HARI.`
reply(kondom)
}
break
case "curhat":{
if (!q) return reply('siapa ingin kau ajak curhat')
let cur = q.toUpperCase()
let hat = `Usiaku 19 tahun. Aku sangat mencintai ${cur}, aku punya semua Figurine dan wallpapernya. Aku berdoa setiap malam dan berterima kasih atas segala hal yang telah ia berikan kepadaku. "${cur} adalah cinta" aku bilang "${cur} adalah Tujuan Hidupku". Temanku datang ke kamarku dan berkata "HALU LU ANJING !!". Aku tau dia cemburu atas kesetiaanku kepada ${cur}. Lalu kukatakan padanya "BACOT NJING !!". Temanku menampol kepalaku dan menyuruhku untuk tidur. Kepalaku sakit dan aku menangis. Aku rebahan di kasur yang dingin, lalu ada sesuatu yang hangat menyentuhku. Ternyata ${cur} datang ke dalam kamarku, Aku begitu senang bertemu ${cur}. Dia membisikan ke telingaku, "Kamu adalah impianku" Dengan tangannya dia meraih diriku. Aku melebarkan pantatku keatas demi ${cur}. Dia menusukan sesuatu kedalam Anggusku. begitu sakit, tapi kulakukan itu demi ${cur}. Aku ingin memberikan kepuasan kepada ${cur}. Dia meraum bagaikan singa, disaat dia melepaskan cintanya kedalam Anggusku. Temanku masuk kekamarku dan berkata "....... Anjing". ${cur} melihat temanku dan berkata " Semua sudah berakhir" Dengan menggunakan kemampuannya Stellar Restoration ${cur} pergi meninggalkan kamarku. "${cur} itu cinta" "${cur} itu kehidupan".`
reply(hat)
}
break
case "nenen":{
if (!q) return reply('nene nin siapa:v')
let nyot = q.toUpperCase()
let pentil = `NENEN NENEN KEPENGEN NENEN SAMA ${nyot}. TETEK GEDE NAN KENCANG MILIK ${nyot} MEMBUATKU KEPENGEN NENEN. DIBALUT PAKAIAN KETAT YANG ADUHAI CROOOOTOTOTOTOTOT ANJING SANGE GUA BANGSAT. ${nyot}, PLIS DENGERIN BAIK BAIK. TOLONG BUKA BAJU SEBENTAR SAJA PLISSS TOLOOONG BANGET, BIARKAN MULUT KERINGKU BISA MENGECAP NENEN ${nyot}. BIARKAN AKU MENGENYOT NENENMU ${nyot}. AKU RELA NGASIH SESEMBAHAN APA AJA BERAPAPUN ITU DUIT YANG AKU BAKAR KHUSUS TERKHUSUS BUATMU. TAPI TOLOOOONG BANGET BUKA BAJUMU AKU MAU NENEN. NENEN NENEEEEN NENEN ${nyot} WANGIIII`
reply(pentil)
}
break



//━━━━━━━━━━━━━━━[ OWNER MENU ]━━━━━━━━━━━━━━━━━\\
case "bcaudio":{
if (!isOwner) return reply(mess.owner)
react('⏳')
let media = await Satzz.downloadMediaMessage(qmsg)
for (let i of Object.keys(db.data.users)) Satzz.sendMessage(i, {audio: media, ptt: true, wavefrom: new Uint8Array(64), mimetype: 'audio/mpeg', contextInfo:{externalAdReply:{showAdAttribution:true,title:`[ BROADCAST AUDIO ]`, body: `${week}, ${calender}`, mediaType: 1, thumbnail: thumb}}})
react('✔️')
}
break
case "bc":{
if (!isOwner) return reply(mess.owner)
react('⏳')
for (let i of Object.keys(db.data.users)) {
Satzz.sendMessage(i, {text:`[ BROADCAST ]\n\n${q}`, contextInfo:{ externalAdReply:{ showAdAttribution: true, renderLargerThumbnail: true, containsAutoReply: true, title: `⌜ ${wm} ⌟`, body: `${week}, ${calender}`,  mediaType: 1,  sourceUrl: sgc, thumbnail: thumb}}});
await sleep(300)
}
react('✔️')
}
break
case "q":
case "quoted":{
if (!m.quoted) return reply("Reply to the message!!");
let wokwol = await Satzz.serializeM(await m.getQuotedObj());
if (!wokwol.quoted) return m.reply("The replied message does not contain a quote");
await wokwol.quoted.copyNForward(m.chat, true);
}
break;
case "addprem":{
if (!isOwner) return reply(mess.owner)
if (!quoted) return reply(`balas pesan target!`)
if(!db.data.users[m.quoted.sender]) return reply("User belom terdaftar di database bot")
var nomernya = m.quoted.sender
var waktunya = q
var namanye = await Satzz.getName(m.quoted.sender)
if(waktunya == undefined) return reply("masukan waktu\ns = detik\nh = jam\nd =hari")
_prem.addPremiumUser(nomernya, waktunya,namanye, premium)
const toMs = require('ms')
const msToDate = (ms) => {
let days = Math.floor(ms / (24 * 60 * 60 * 1000))
let daysms = ms % (24 * 60 * 60 * 1000)
let hours = Math.floor((daysms) / (60 * 60 * 1000))
let hoursms = ms % (60 * 60 * 1000)
let minutes = Math.floor((hoursms) / (60 * 1000))
let minutesms = ms % (60 * 1000)
let sec = Math.floor((minutesms) / (1000))
return days + " Hari " + hours + " Jam " + minutes + " Menit"
}
let teks =`
_*SUCCESS*_\n
🆔 *Name :* ${namanye}
📛 *Number:* ${nomernya.split("@")[0]}
📆 *Days:* ${msToDate(toMs(waktunya))}
📉 *Countdown:* ${toMs(waktunya)}`
let text = `HALO KAK AKU *${wm}*
kamu telah terdaftar sabagai user premium\n
📛 *Number:* ${nomernya.split("@")[0]}
📆 *Days:* ${msToDate(toMs(waktunya))}
📉 *Countdown:* ${toMs(waktunya)}\n
terimakasih sudah menggunakan ${wm}`
reply(teks)
Satzz.sendMessage(nomernya,{text, mentions: [nomernya] })
}
break
case "delprem":{
if (!isOwner) return onlyOwner()
let users = m.mentionedJid[0] ? m.mentionedJid : m.quoted ? [m.quoted.sender] : [q.replace(/[^0-9]/g, "") + "@s.whatsapp.net"];
if (users) {
if(!_prem.checkPremiumUser (users, premium)) return reply("Maap kak user tersebut tidak ada di database")
_prem.delPremiumUser (users, premium)
reply(`Succes delete premium ${Input.split("@")[0]}`)
} else reply("Tag/Reply/Input nomer target")
}
break
case "listprem":{
const ms = require('parse-ms')
let txt = `*── 「 LIST PREMIUM 」 ──*\nTotal : ${premium.length}\n\n`
let men = [];
for (let i of premium) {
men.push(i.id)
let cekvip = ms(i.expired - Date.now())
txt += `*Name :* ${i.name}\n*Number :* wa.me/${i.id.split("@")[0]}\n*Expired :* ${cekvip.days} Hari ${cekvip.hours} Jam ${cekvip.minutes} Menit ${cekvip.seconds} Detik\n\n`
}
reply(txt, men)
}
break
case "cekprem":
case "cekpremium":{
if (!isPremium && !isOwner) return reply(`Kamu bukan user premium`)
const ms = require('parse-ms')
let cekvip = ms(_prem.getPremiumExpired(m.sender, premium) - Date.now())
let premiumnya = `${cekvip.days} day(s) ${cekvip.hours} hour(s) ${cekvip.minutes} minute(s) ${cekvip.seconds} second(s)`
reply(premiumnya)
}
break
case "blockcmd":{
if (!isCreator) return reply(mess.owner);
if (!q) return reply("Sorry, the command you want to block has not been specified.");
blockcmd.push(q);
fs.writeFileSync("./src/blockcmd.json", JSON.stringify(blockcmd));
reply(`Command *${q}* has been blocked.`);
}
break;
case "unblockcmd":{
if (!isCreator) return reply(mess.owner);
if (blockcmd.length == 0)
return reply("No commands are currently blocked.");
if (!q)return reply("Sorry, the command you want to unblock has not been specified.");
blockcmd.splice(q, 1);
fs.writeFileSync("./src/blockcmd.json", JSON.stringify(blockcmd));
reply(`The command *${q}* has been unblocked`);
}
break;
case "unblockallcmd":{
if (!isCreator) return reply(mess.owner);
if (blockcmd.length == 0) return reply("No commands are currently blocked.");
blockcmd.splice(0, blockcmd.length);
fs.writeFileSync("./src/blockcmd.json",JSON.stringify(blockcmd, null, 2));
reply("All blocked commands have been unblocked.");
}
break;
case "listblockcmd":{
if (blockcmd.length == 0) return reply("No commands are currently blocked.");
let txt = `*── 「 LIST OF BLOCKED COMMAND 」 ──*\nTotal : ${blockcmd.length}\n\n`;
for (let i = 0; i < blockcmd.length; i++) txt += `${i + 1}. ${blockcmd[i]}\n`;
reply(txt);
}
break;
case 'restart': case 'mulaiulang': {
if (!isOwner && !itsMe) return reply(mess.owner)
let bot = db.data.others['restart']
if (bot) {
db.data.others['restart'].m = m
db.data.others['restart'].from = from
} else {db.data.others['restart'] = { m: m,from: from }
}
await Satzz.sendMessage(from, {text: `_Restarting ${wm}_`})
await Satzz.sendMessage(from, {text: "_Succes_"})
await sleep(1000)
process.send('reset')
}
break
case "test": case "tes":{
Satzz.sendPoll(from, "Quick Test", ["menu","owner"])
}
break
case "addfile":{
if (!isOwner) return reply(mess.owner)
if (!quoted) return reply('balas media')
let medium = await Satzz.downloadAndSaveMediaMessage(qmsg, q.split("|")[0])
let res = await uploadToGH(global.githubcode, "SatganzDevs", "DATABASES", q.split("|")[1], medium, global.calender)
reply(res)
await fs.unlinkSync(medium)
}
break
case "getcase":{
try{
if (!isOwner) return reply(mess.owner)
if (!q) return reply(mess.query)
reply(await getCases(q))
} catch(err) {
reply(`Case ${q} tidak di temukan`)
}
}
break
case "backup":{
if (!isCreator) return reply(global.mess.owner) 
reply(global.mess.wait)
const archiver = require('archiver');
const backupFileName = `SIESTA-${week}-${calender}.zip`;
try {
const output = fs.createWriteStream(backupFileName);
const archive = archiver('zip', { zlib: { level: 9 } });
archive.pipe(output);
archive.on('warning', function(err) { if (err.code === 'ENOENT') { console.log(chalk.bgRedBright(chalk.black("[ ERROR ]")),chalk.yellow(err))} else { throw err }});
archive.glob('**/*', { cwd: './', ignore: ['node_modules/**/*', 'session/**', '**/.*', backupFileName]});
await archive.finalize()
await Satzz.sendMessage(m.sender, {document: {url: `./${backupFileName}` }, mimetype: "application/zip", fileName: backupFileName}, {quoted: m}).then(_ => {
if (m.isGroup) return reply(`dikirim ke private chats!`)
fs.unlinkSync(backupFileName)
}) 
} catch (error) {
console.log(chalk.bgRedBright(chalk.black("[ ERROR ]")),chalk.yellow(err))
reply('Terjadi kesalahan saat membuat arsip.');
}
}
break
case "kirim": case "send":{
if (!q) return (`mana urlnya? contoh: .${command} https//xnxxxx.mp4|lol`)
reply(global.mess.wait)
let urls =  q
Satzz.sendMessage(from, {video: {url: urls }, caption: q.split('|')[1] || "", contextInfo},{quoted: setQuoted})
}
break
case "setppbot":{
if (!isCreator) return reply(global.mess.owner);
const {apa} = await Satzz.sendMessage(from, {text: "Wait a second..."})
let medis = await Satzz.downloadAndSaveMediaMessage(qmsg, "ppg");
var { img } = await generateProfilePicture(medis);
await Satzz.query({tag: "iq", attrs: { to: botNumber, type: "set", xmlns: "w:profile:picture" }, content: [{tag: "picture", attrs: { type: "image" }, content: img }]});
fs.unlinkSync(medis);
await Satzz.sendMessage(m.chat, { text: "sucess update profile picture", edit: apa });
}
break;
case "block":{
if (!isCreator) return reply(global.mess.owner);
let users = m.mentionedJid[0] ? m.mentionedJid : m.quoted ? [m.quoted.sender] : [q.replace(/[^0-9]/g, "") + "@s.whatsapp.net"];
await Satzz.updateBlockStatus(users, "block").then((res) => reply(jsonformat(res))).catch((err) => reply("error"));
}
break;
case "unblock":{
if (!isCreator) return reply(global.mess.owner);
let users = m.mentionedJid[0] ? m.mentionedJid : m.quoted ? [m.quoted.sender] : [q.replace(/[^0-9]/g, "") + "@s.whatsapp.net"];
await Satzz.updateBlockStatus(users, "unblock").then((res) => reply(jsonformat(res))).catch((err) => reply("error"));
}
break;
case "public":{
if (!isCreator && !itsMe) return reply(mess.owner);
if (Satzz.public == true) return reply(`Already in Public Mode!`)
Satzz.public = true;
reply("Success Change To Public Mode");
}
break;
case "self":{
if (!isCreator && !itsMe) return reply(mess.owner);
if (!Satzz.public) return reply(`Already in Self Mode!`)
Satzz.public = false;
reply("Success Change To Self Mode");
}
break;



//━━━━━━━━━━━━━━━[ MENFESS ]━━━━━━━━━━━━━━━━━//
case "menfes":
case "menfess":{
if (m.isGroup) return reply("Fitur ini tidak dapat digunakan di grup.");
if (!q) return reply(`Contoh: ${prefix + command} 6282xxxxx`);
this.menfess = this.menfess ? this.menfess : {};
let targetNumber = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
var checkTarget = await Satzz.onWhatsApp(targetNumber);
if (targetNumber == m.sender) return reply("Tidak bisa mengirim pesan ke nomor sendiri!");
if (checkTarget.length == 0) return reply(`Nomor tersebut tidak terdaftar di WhatsApp.\n\nMasukkan nomor yang valid dan terdaftar di WhatsApp.`);
let id = + new Date();
this.menfess[id] = {id, a: m.sender, b: targetNumber, state: "WAITING", check: function (who = "") {return [this.a, this.b].includes(who)},other: function (who = "") {return who === this.a ? this.b : who === this.b ? this.a : ""}};
reply(`Menunggu penerima untuk mengkonfirmasi...`);
Satzz.sendMessage(targetNumber, {text: `Halo ${await Satzz.getName(targetNumber)}\nSeseorang ingin mengirimkan pesan anonim denganmu. Balas *Y* untuk menerima dan *N* untuk menolak.`, contextInfo: {externalAdReply: {title: "MENFESS", body: calender, thumbnailUrl: "https://telegra.ph/file/724c6f109aa780b2d8eb7.jpg", mediaType: 1, renderLargerThumbnail: true}}})
}
break;
default:
let alias = JSON.parse(fs.readFileSync("./message/command.json"))
let didyoumean = require('didyoumean')
let similarity = require('similarity')
let mean = didyoumean(command, alias)
let sim = similarity(command, mean)
let som = sim * 100
let teks = `Did You Mean ${prefix + mean} ?\n\n ◦ Menu Name: *${prefix + mean}*\n  ◦ Similarity: *${parseInt(som)}%*`
if (mean) Satzz.sendMessage(m.chat, { poll: { name: teks, values: [`${mean} ${q ? q : ''}`,`thanks`], selectableCount:1, contextInfo:{mentionedJid:[m.sender]}}})
}   
}



//━━━━━━━━━━━━━━━[ ERROR ]━━━━━━━━━━━━━━━━━// 
} catch (err) {
const Ownerins = async (teki) => {
return await Satzz.sendMessage(`6281316701742@s.whatsapp.net`, {text: teki, contextInfo: {externalAdReply: {title: "ERROR", thumbnail: await getBuffer(await pickRandom(global.img)), mediaType: 1, renderLargerThumbnail: true}}})
}
console.log(chalk.bgRedBright(chalk.black("[ ERROR ]")),chalk.yellow(err))
let tekidum =`]─────「 *SYSTEM-ERROR* 」─────[\n\n${util.format(err)}\n\n© ${botname}`
Ownerins(tekidum)
m.reply(`Someting went Wrong`);
}
}
//━━━━━━━━━━━━━━━[ END OF EXPORT ]━━━━━━━━━━━━━━━━━//



//━━━━━━━━━━━━━━━[ FILE UPDATE ]━━━━━━━━━━━━━━━━━\\
let file = require.resolve(__filename);
fs.watchFile(file, () => {
fs.unwatchFile(file);
console.log(chalk.bgCyanBright(chalk.black("[ UPDATE ]")),chalk.red(`${__filename}`))
delete require.cache[file];
require(file);
});
