/* SC SIESTA - MD V5
BASE : HISOKA OLD
CREATOR : SATZZ
*/
const fs = require("fs") 
const chalk = require("chalk") 


exports.memberUpdate = async(satganzdevs, anu) => {
try {
let metadata = await satganzdevs.groupMetadata(anu.id)
const memk = metadata.participants.length
const groupDesc =  metadata.desc || []
let participants = anu.participants
for (let num of participants) {
let ppuser = await satganzdevs.profilePictureUrl(num, "image").catch(_ => "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60");
let usname = await satganzdevs.getName(num)




if (anu.action == 'add') {
satganzdevs.sendMessage(anu.id, 
{text:`Yokoso *@${num.split('@')[0]}*💐`, 
contextInfo: {
mentionedJid : [num], 
externalAdReply:{
title: `WELCOME MESSAGE`, 
mediaType: 1,
thumbnailUrl: ppuser, 
renderLargerThumbnail: true
}}});
} else if (anu.action == 'remove') {
satganzdevs.sendMessage(anu.id, 
{ text: `Sayonara *@${num.split('@')[0]}*💐`, 
contextInfo: { 
mentionedJid : [num],
externalAdReply:{
title: `GOODBYE MESSAGE`, 
mediaType: 1,
thumbnailUrl: ppuser,  
renderLargerThumbnail: true,
}}});
} else if (anu.action == 'promote') {
satganzdevs.sendMessage(anu.id, {text: `@${num.split('@')[0]} Sekarang Telah Menjadi Admin.`, contextInfo: { 
mentionedJid : [num],
externalAdReply:{
title: `Greeting Message`, 
mediaType: 1,
thumbnailUrl: ppuser, 
renderLargerThumbnail: true
}}});
} else if (anu.action == 'demote') {
satganzdevs.sendMessage(anu.id, {text: `@${num.split('@')[0]} Telah Diturunkan Dari Admin Menjadi Member biasa.`, contextInfo: { mentionedJid : [num], 
externalAdReply:{
title: `Greeting Message`, 
mediaType: 1,
thumbnailUrl: ppuser, 
renderLargerThumbnail: true
}}});
} else console.log(anu.action)
}
} catch (error) {
console.log(chalk.bgRedBright(chalk.black("[ ERROR ]")),chalk.yellow(error))
}
}

let file = require.resolve(__filename);
fs.watchFile(file, () => {
fs.unwatchFile(file);
console.log(chalk.bgCyanBright(chalk.black("[ UPDATE ]")),chalk.red(`${__filename}`))
delete require.cache[file];
require(file);
});
